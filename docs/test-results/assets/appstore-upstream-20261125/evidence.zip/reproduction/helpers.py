import base64,json,re,time
from pathlib import Path
from device_session import DeviceSession,WORK


def parse(out,label='STORE_STATE'):
 match=re.search(r'^'+label+r'\s+(\{.*\}|\[.*\])$',out,re.MULTILINE)
 if not match:raise RuntimeError('Missing state '+label+': '+out[-500:])
 return json.loads(match.group(1))


def state(d):
 return parse(d.command("print('STORE_STATE',json.dumps({'foreground':type(mpos.ui.screen_stack[-1][0]).__name__,'refreshing':getattr(_store,'_refresh_in_progress',False),'catalog_error':getattr(_store,'_catalog_error',False),'loaded':getattr(_store,'_data_loaded',False),'apps':len(_store.apps),'categories':getattr(_store,'_category_options',[])}))",show=False))


def wait_store(d,timeout=100):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  time.sleep(1)
  value=state(d)
  if value['loaded'] and not value['refreshing']:
   print('STORE_READY',value,flush=True)
   if value['catalog_error']:raise RuntimeError('Store failed catalog: '+str(value))
   return value
 raise TimeoutError('Catalog refresh timed out')


def wait_action(d,timeout=130):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  time.sleep(1)
  value=parse(d.command("print('STORE_ACTION',json.dumps({'busy':_detail._action_in_progress,'label':_detail.install_label.get_text(),'message':_detail.long_desc_label.get_text(),'details_error':getattr(_detail,'_details_error',False)}))",show=False),'STORE_ACTION')
  if not value['busy']:print('DETAIL_READY',value,flush=True);return value
 raise TimeoutError('Store install/uninstall timed out')


def capture(d,label):
 output=d.command("import gc;gc.collect();from mpos.ui.testing import capture_screenshot;_capture_pixels=capture_screenshot(width=240,height=320,color_format=lv.COLOR_FORMAT.RGB565)\nfor _offset in range(0,len(_capture_pixels),2048):print('RGB565_DATA',ubinascii.b2a_base64(memoryview(_capture_pixels)[_offset:_offset+2048]).decode().strip())\ndel _capture_pixels;gc.collect()",timeout=90,show=False)
 data=b''.join(base64.b64decode(part) for part in re.findall(r'^RGB565_DATA\s+(\S+)',output,re.MULTILINE))
 if len(data)!=240*320*2:raise RuntimeError('RGB565 capture size mismatch: '+str(len(data)))
 (WORK/(label+'.rgb565')).write_bytes(data)
 rgb=bytearray(240*320*3)
 for offset in range(0,len(data),2):
  pixel=data[offset] | (data[offset+1]<<8)
  red=(pixel>>11)&31;green=(pixel>>5)&63;blue=pixel&31
  pos=offset//2*3
  rgb[pos:pos+3]=bytes(((red<<3)|(red>>2),(green<<2)|(green>>4),(blue<<3)|(blue>>2)))
 from PIL import Image
 Image.frombytes('RGB',(240,320),bytes(rgb)).save(WORK/(label+'.png'))
 print('SCREENSHOT_RGB565',label,flush=True)


def result(name,value):
 release=json.loads((WORK.parents[1]/'appstore-upystore/tmp/appstore-release/release.json').read_text())
 file=WORK/('official-device-results-'+release['sha256'][:8]+'.json')
 rows=json.loads(file.read_text(encoding='utf-8')) if file.exists() else []
 rows.append({'case':name,'result':'passed','expected_mpk_sha256':release['sha256'],'actual':value})
 file.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
 print('CASE_PASSED',name,flush=True)
