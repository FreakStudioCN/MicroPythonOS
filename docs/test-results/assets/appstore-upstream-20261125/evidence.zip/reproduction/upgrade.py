import json
from pathlib import Path
import time
from device_session import DeviceSession
import helpers

WORK=Path(__file__).parent
REPO=WORK.parents[1]/'appstore-upstream-clean'
release=json.loads((REPO/'tmp/appstore-upstream-release/release.json').read_text())

def record(case,actual):
    path=WORK/('device-results-'+release['sha256'][:8]+'.json')
    rows=json.loads(path.read_text()) if path.exists() else []
    rows.append({'case':case,'result':'passed','mpk_sha256':release['sha256'],'actual':actual,'scope':'controlled local packages, no reset during upgrade; not published store revisions'})
    path.write_bytes((json.dumps(rows,indent=2)+'\n').encode())
    print('BUILTIN_PASS',case,flush=True)

def detail(d,key):
    d.command("_store.show_app_detail(next(a for a in _store.apps if a.fullname=='com.freakstudio.storetest_%s'));_detail=mpos.ui.screen_stack[-1][0]"%key)
    return helpers.wait_action(d)

def probe(d,key,marker,value):
    d.command('_detail._open_button.send_event(lv.EVENT.CLICKED,None)')
    time.sleep(.4)
    d.command("_probe=mpos.ui.screen_stack[-1][0];print('BUILTIN_HELPER_ACTIVE',_probe.appFullName,_probe.helper_marker,_probe.helper_result,_probe.helper_file)\nif _probe.helper_marker!=%r or _probe.helper_result!=%d:raise RuntimeError('Wrong helper code')"%(marker,value))
    if key=='upgrade' and marker=='v2':helpers.capture(d,'builtin-renamed-helper-v2')
    d.command('_probe.finish();_detail.finish()')

with DeviceSession('builtin-controlled-upgrade.log') as d:
    d.command("_um=appstore_core.AppUpdateManager.get_instance();_was_running=globals().get('_sync_original_running',_um._running);_um.stop();print('BUILTIN_CORE_IDENTITY',_um is sys.modules['appstore_core'].AppUpdateManager.get_instance())")
    deadline=time.monotonic()+180
    while True:
        state=helpers.parse(d.command("print('REQUEST_IDLE',json.dumps({'busy':_um._check_in_progress,'queued':len(store_source._REQUESTS)}))",show=False),'REQUEST_IDLE')
        if not state['busy'] and not state['queued']:break
        if time.monotonic()>deadline:raise TimeoutError('Requests did not settle')
        time.sleep(1)
    d.command("AppManager.install_mpk('/data/fixture-bundle.zip','/data/appstore-test');sys.path.insert(0,'/data/appstore-test');import device_transport;device_transport.install();device_transport.revision=1;SharedPreferences('com.micropythonos.appstore').edit().put_string('store_source','upystore').put_string('store_query','').put_string('update_notifications','true').commit();AppManager.start_app('com.micropythonos.appstore');_store=mpos.ui.screen_stack[-1][0];_upgrade_start_ticks=__import__('time').ticks_ms()")
    try:
        helpers.wait_store(d)
        for key in ['upgrade','peer']:
            value=detail(d,key)
            if value['label']!='Install':raise RuntimeError('Fixture baseline unexpectedly installed')
            d.command('_detail.install_button.send_event(lv.EVENT.CLICKED,None)')
            value=helpers.wait_action(d)
            if value['label']!='Uninstall' or 'Install failed' in value['message']:raise RuntimeError(str(value))
            probe(d,key,'v1',5)
            record('helper_'+key+'_install_and_start_v1',{'version':'1.0.0','revision':1,'result':5})
        d.command("if 'dshell_storetest_upgrade_helper_removed' not in sys.modules:raise RuntimeError('Old-only helper not loaded')\nif not store_install.exists('/apps/com.freakstudio.storetest_upgrade/assets/dshell_storetest_upgrade_helper_removed.py'):raise RuntimeError('Missing old-only file')\nprint('BUILTIN_OLD_ONLY_MODULE_AND_FILE_CONFIRMED');device_transport.revision=3;_store.refresh_list()")
        helpers.wait_store(d)
        detail(d,'upgrade')
        d.command('_detail.update_button.send_event(lv.EVENT.CLICKED,None)')
        value=helpers.wait_action(d)
        if 'Missing main/launcher' not in value['message']:raise RuntimeError(str(value))
        d.command("if AppManager.get('com.freakstudio.storetest_upgrade').version!='1.0.0' or sys.modules['dshell_storetest_upgrade_helper'].MARKER!='v1':raise RuntimeError('Old version changed')\n_detail.finish();_store.finish();device_transport.revision=2;_um.stop()")
        record('invalid_launcher_rejected_and_v1_preserved',value)
        deadline=time.monotonic()+40
        while True:
            value=helpers.parse(d.command("print('UPDATE_IDLE',json.dumps({'busy':_um._check_in_progress,'queued':len(store_source._REQUESTS)}))",show=False),'UPDATE_IDLE')
            if not value['busy'] and not value['queued']:break
            if time.monotonic()>deadline:raise TimeoutError('Controlled check did not settle')
            time.sleep(.4)
        d.command('_um.suppress_notifications=False;_um.clear_updates_notification();_um._last_check_ts=None;_um.check_for_updates_now()')
        deadline=time.monotonic()+35
        while time.monotonic()<deadline:
            value=helpers.parse(d.command("from mpos import NotificationManager;_notification=NotificationManager.get_notification(_um.NOTIFICATION_ID);print('NOTIFICATION_STATE',json.dumps({'present':_notification is not None,'updates':len(_um.updatable_apps),'busy':_um._check_in_progress}))",show=False),'NOTIFICATION_STATE')
            if value['present'] and value['updates']==2 and not value['busy']:break
            time.sleep(.4)
        else:raise RuntimeError('Notification not posted: '+str(value))
        d.command("if _notification.intent.app_fullname!='com.micropythonos.appstore':raise RuntimeError('Wrong target')\nNotificationManager.trigger(_um.NOTIFICATION_ID);_store=mpos.ui.screen_stack[-1][0]")
        helpers.wait_store(d)
        d.command("print('BUILTIN_NOTIFICATION_DESTINATION',_store.appFullName,_store._selected_category)\nif _store.appFullName!='com.micropythonos.appstore' or _store._selected_category!='Updates':raise RuntimeError('Wrong destination')\n_store.update_all_button.send_event(lv.EVENT.CLICKED,None)")
        record('background_notification_opens_builtin_updates',value)
        deadline=time.monotonic()+80
        while time.monotonic()<deadline:
            time.sleep(.5)
            value=helpers.parse(d.command("print('BATCH_STATE',json.dumps({'busy':getattr(_store,'_batch_updating',False),'versions':[AppManager.get('com.freakstudio.storetest_'+k).version for k in ['upgrade','peer']]}))",show=False),'BATCH_STATE')
            if not value['busy'] and value['versions']==['1.1.0','1.1.0']:break
        else:raise TimeoutError('Batch update failed')
        d.command("for name in ['dshell_storetest_upgrade_helper','dshell_storetest_upgrade_helper_removed','dshell_storetest_peer_helper']:\n if name in sys.modules:raise RuntimeError('Old cached helper retained: '+name)\nfor name in ['dshell_storetest_upgrade_helper.py','dshell_storetest_upgrade_helper_removed.py']:\n if store_install.exists('/apps/com.freakstudio.storetest_upgrade/assets/'+name):raise RuntimeError('Obsolete helper file retained: '+name)\nif not store_install.exists('/apps/com.freakstudio.storetest_upgrade/assets/dshell_storetest_upgrade_helper_renamed.py'):raise RuntimeError('Renamed helper missing')\nprint('BUILTIN_REMOVED_FILES_AND_MODULES_ABSENT')")
        record('batch_upgrade_removes_obsolete_files_and_cached_modules',value)
        helpers.wait_store(d)
        for key in ['upgrade','peer']:
            detail(d,key)
            probe(d,key,'v2',105)
            record('helper_'+key+'_starts_new_code_without_reset',{'version':'1.1.0','result':105,'helper_renamed':key=='upgrade'})
        for key in ['upgrade','peer']:
            detail(d,key);d.command('_detail.install_button.send_event(lv.EVENT.CLICKED,None)')
            value=helpers.wait_action(d)
            if value['label']!='Install':raise RuntimeError('Uninstall failed')
            d.command("if AppManager.is_installed_by_name('com.freakstudio.storetest_%s') or store_install.read_receipt('com.freakstudio.storetest_%s') is not None:raise RuntimeError('Fixture retained')\n_detail.finish()"%(key,key))
            record('helper_'+key+'_uninstall',True)
    finally:
        d.command("while type(mpos.ui.screen_stack[-1][0]).__name__!='Launcher':mpos.ui.screen_stack[-1][0].finish()\ndevice_transport.uninstall();sys.path.remove('/data/appstore-test');_um.clear_updates_notification();_um._last_check_ts=None\nif _was_running:_um.start()\nprint('BUILTIN_REAL_TRANSPORT_RESTORED')")
print('BUILTIN_CONTROLLED_UPGRADE_COMPLETE',flush=True)
