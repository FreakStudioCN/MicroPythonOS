from pathlib import Path
import queue
import serial
from serial.tools import list_ports
import threading
import time

WORK=Path(__file__).resolve().parent


class DeviceSession:
 def __init__(self,logname='runtime.log'):
  ports=[p for p in list_ports.comports() if p.vid==0x303A and p.pid==0x4001 and p.serial_number=='E072A1F6807C0000']
  if len(ports)!=1:raise RuntimeError('Expected D-Shell runtime port')
  self.ser=serial.Serial(port=None,baudrate=115200,timeout=.05,write_timeout=90)
  self.ser.port=ports[0].device;self.ser.dtr=True;self.ser.rts=False;self.ser.open()
  self.transcript=bytearray();self.sequence=0;self.logpath=WORK/logname;self.remote_ready=False
  self.queue=queue.Queue();self.running=True
  self.reader=threading.Thread(target=self._read_loop,daemon=True);self.reader.start()
  self.ser.write(b'\r\n')
  initial=bytearray();deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   try:initial.extend(self.queue.get(timeout=.05))
   except queue.Empty:continue
   if b'>>>' in initial:break
  self.transcript.extend(initial)
 def _read_loop(self):
  try:
   while self.running:
    data=self.ser.read(self.ser.in_waiting or 1)
    if data:self.queue.put(data)
  except (serial.SerialException,OSError):pass
 def command(self,code,timeout=150,show=True):
  self.sequence+=1;marker='__UPYSTORE_END_%d__'%self.sequence
  wrapped="try:\n exec(%r,globals())\nexcept Exception as _review_error:\n print('__UPYSTORE_COMMAND_ERROR__')\n __import__('sys').print_exception(_review_error)\nfinally:\n print(%r)"%(code,marker)
  if not self.remote_ready:
   helper="def _codex_call(_code,_marker):\n try:exec(_code,globals())\n except Exception as _error:\n  print('__UPYSTORE_COMMAND_ERROR__')\n  __import__('sys').print_exception(_error)\n finally:print(_marker)"
   payload=('exec(%r,globals());_codex_call(%r,%r)\r\n'%(helper,code,marker)).encode()
   self.remote_ready=True
  else:
   payload=('_codex_call(%r,%r)\r\n'%(code,marker)).encode()
  for i in range(0,len(payload),32):
   self.ser.write(payload[i:i+32]);time.sleep(.01)
  out=bytearray();deadline=time.monotonic()+timeout
  while time.monotonic()<deadline:
   try:out.extend(self.queue.get(timeout=.1))
   except queue.Empty:continue
   normalized=out.replace(b'\r',b'')
   if ('\n'+marker+'\n').encode() in normalized and b'>>>' in normalized.split(marker.encode())[-1]:break
  else:
   self.transcript.extend(out);self.logpath.write_bytes(self.transcript)
   raise TimeoutError('Friendly REPL command timed out: '+out.decode(errors='replace')[-1000:])
  self.transcript.extend(out);self.logpath.write_bytes(self.transcript)
  lines=out.decode(errors='replace').replace('\r','').splitlines()
  result='\n'.join(line for line in lines if not line.startswith(('>>> exec(','exec(','>>> _codex_call(','_codex_call(')) and line!=marker)
  if show:print(result,flush=True)
  if '__UPYSTORE_COMMAND_ERROR__' in result.splitlines():raise RuntimeError(result)
  return result
 def wait_output(self,token,timeout=180):
  output=bytearray();deadline=time.monotonic()+timeout
  while time.monotonic()<deadline:
   try:data=self.queue.get(timeout=.1)
   except queue.Empty:continue
   output.extend(data);self.transcript.extend(data)
   normalized=output.replace(b'\r',b'')
   if token.encode() in normalized and b'\n' in normalized.split(token.encode())[-1]:
    self.logpath.write_bytes(self.transcript)
    return output.decode(errors='replace').replace('\r','')
  self.logpath.write_bytes(self.transcript)
  raise TimeoutError('Device completion token not observed: '+token)
 def close(self):
  self.running=False;self.reader.join(timeout=1);self.ser.close()
  while not self.queue.empty():self.transcript.extend(self.queue.get_nowait())
  self.logpath.write_bytes(self.transcript)
 def __enter__(self):return self
 def __exit__(self,*args):self.close()
