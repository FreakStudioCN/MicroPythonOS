import json
from pathlib import Path
import time
from device_session import DeviceSession
import helpers

WORK = Path(__file__).parent
RELEASE = json.loads((WORK.parents[1] / 'appstore-upstream-clean/tmp/appstore-upstream-release/release.json').read_text())


def record(case, actual):
    path = WORK / ('device-results-' + RELEASE['sha256'][:8] + '.json')
    rows = json.loads(path.read_text()) if path.exists() else []
    rows.append({'case': case, 'result': 'passed', 'mpk_sha256': RELEASE['sha256'], 'actual': actual})
    path.write_bytes((json.dumps(rows, indent=2)+'\n').encode())
    print('BUILTIN_PASS', case, flush=True)


with DeviceSession('builtin-final-checks.log') as d:
    d.command("_um=appstore_core.AppUpdateManager.get_instance();_was_running=_um._running;_um.stop();SharedPreferences('com.micropythonos.appstore').edit().put_string('store_query','').commit();AppManager.start_app('com.micropythonos.appstore');_store=mpos.ui.screen_stack[-1][0]")
    try:
        helpers.wait_store(d, 210)
        d.command("_store.category_dropdown.set_selected(_store._category_options.index('All'));_store.category_dropdown.send_event(lv.EVENT.VALUE_CHANGED,None)")
        helpers.wait_store(d, 210)
        value = helpers.parse(d.command("print('BUILTIN_FULL_CATALOG',json.dumps({'source':store_source.current_source(),'merged_apps':len(_store.apps),'visible_rows':len(_store._displayed_apps),'categories':_store._category_options,'shared_system_app':any(a is AppManager.get(a.fullname) for a in _store.apps)}))"), 'BUILTIN_FULL_CATALOG')
        if value['merged_apps'] < 500 or value['visible_rows'] < 500 or value['shared_system_app']:
            raise RuntimeError(str(value))
        record('real_complete_catalog_all_rows_and_isolated_objects', value)
        helpers.capture(d, 'builtin-full-catalog')
        value = helpers.parse(d.command("_store.category_dropdown.set_selected(_store._category_options.index('Utilities'));_store.category_dropdown.send_event(lv.EVENT.VALUE_CHANGED,None);print('BUILTIN_FILTERED',json.dumps({'category':_store._selected_category,'rows':len(_store._displayed_apps)}))"), 'BUILTIN_FILTERED')
        if value['category'] != 'Utilities' or value['rows'] < 1:
            raise RuntimeError(str(value))
        record('real_category_filter', value)
        d.command("_saved_updates=_um.updatable_apps;_saved_check=_um._last_check_ts;_saved_clear=_um.clear_updates_notification;_saved_request=_um.check_for_updates_now;_search_calls=[];_um.clear_updates_notification=lambda:_search_calls.append('clear');_um.check_for_updates_now=lambda:_search_calls.append('request')\ntry:\n _store.prefs.edit().put_string('store_query','CC Skill Smoke').commit()\n _store._store_query_changed('CC Skill Smoke')\n if _um.updatable_apps is not _saved_updates or _um._last_check_ts!=_saved_check or _search_calls:raise RuntimeError('Search changed update state')\nfinally:\n _um.clear_updates_notification=_saved_clear\n _um.check_for_updates_now=_saved_request\n_store.refresh_list()")
        record('search_does_not_clear_updates_or_start_background_check', helpers.wait_store(d, 180))
        d.command("_store.category_dropdown.set_selected(_store._category_options.index('All'));_store.category_dropdown.send_event(lv.EVENT.VALUE_CHANGED,None)")
        helpers.capture(d, 'builtin-final-search')
    finally:
        d.command("while type(mpos.ui.screen_stack[-1][0]).__name__!='Launcher':mpos.ui.screen_stack[-1][0].finish()\n_um.clear_updates_notification()\nif _was_running:_um.start()")
    d.command("if any(AppManager.is_installed_by_name('com.freakstudio.storetest_'+key) for key in ['upgrade','peer']):raise RuntimeError('Fixture retained')\nif os.listdir('/cache/com.micropythonos.appstore/install/stage') or os.listdir('/cache/com.micropythonos.appstore/install/backup'):raise RuntimeError('Unclean install workspace')\nif 'lib' in os.listdir('/'):raise RuntimeError('Framework overlay found')\nif 'device_transport' in sys.modules and sys.modules['device_transport']._original is not None:raise RuntimeError('Fixture transport retained')\nif AppManager.is_installed_by_name('com.freakstudio.upystore'):raise RuntimeError('Independent app still installed')\nprint('BUILTIN_FINAL_READY',ConnectivityManager.is_online(),TaskManager.keep_running,type(mpos.ui.screen_stack[-1][0]).__name__,AppManager.get('com.micropythonos.appstore').version)\nAppManager.restart_launcher()")
    record('final_cleanup_real_network_and_original_launcher_entry', True)
print('BUILTIN_FINAL_CHECKS_COMPLETE', flush=True)
