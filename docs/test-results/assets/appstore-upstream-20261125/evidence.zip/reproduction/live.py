import json
from pathlib import Path
import shutil
import time
from device_session import DeviceSession

WORK=Path(__file__).parent
REPO=WORK.parents[1]/'appstore-upstream-clean'
release=json.loads((REPO/'tmp/appstore-upstream-release/release.json').read_text())
shutil.copyfile(WORK.parents[0]/'appstore-upstream-20261120/official_helpers.py',WORK/'helpers.py')
import helpers

def record(case,actual):
    path=WORK/('device-results-'+release['sha256'][:8]+'.json')
    rows=json.loads(path.read_text()) if path.exists() else []
    rows.append({'case':case,'result':'passed','mpk_sha256':release['sha256'],'actual':actual})
    path.write_bytes((json.dumps(rows,indent=2)+'\n').encode())
    print('BUILTIN_PASS',case,flush=True)

with DeviceSession('builtin-live-'+release['sha256'][:8]+'.log') as d:
    output=d.command("import sys,os,json,hashlib,ubinascii,mpos.ui,lvgl as lv;from mpos import AppManager,TaskManager,SharedPreferences,ConnectivityManager,BuildInfo;sys.path.insert(0,'apps/com.micropythonos.appstore');import store_source,store_install,app_detail,appstore_core;print('BUILTIN_IDENTITY',json.dumps({'fullname':AppManager.get('com.micropythonos.appstore').fullname,'version':AppManager.get('com.micropythonos.appstore').version,'firmware':BuildInfo.version.release,'source':store_source.current_source(),'online':ConnectivityManager.is_online(),'independent_installed':AppManager.is_installed_by_name('com.freakstudio.upystore'),'files':{name:ubinascii.hexlify(hashlib.sha256(open('/apps/com.micropythonos.appstore/'+name,'rb').read()).digest()).decode() for name in os.listdir('/apps/com.micropythonos.appstore') if not name.startswith('.')}}))",timeout=35)
    value=helpers.parse(output,'BUILTIN_IDENTITY')
    if value['files']!=release['files'] or value['version']!='1.5.4' or value['source']!='upystore' or value['independent_installed']:raise RuntimeError(str(value))
    record('builtin_appstore_identity_and_no_independent_entry',value)
    d.command("AppManager.start_app('com.micropythonos.appstore');_store=mpos.ui.screen_stack[-1][0]")
    record('real_search_and_official_list',helpers.wait_store(d,180))
    d.command("_store.category_dropdown.set_selected(_store._category_options.index('All'));_store.category_dropdown.send_event(lv.EVENT.VALUE_CHANGED,None);_index=next(i for i,a in enumerate(_store._displayed_apps) if a.fullname=='com.example.cc_skill_smoke');_app=_store._displayed_apps[_index]\nif _app is AppManager.get(_app.fullname):raise RuntimeError('Shared mutable store object')\n_store.apps_list.get_child(_index).send_event(lv.EVENT.CLICKED,None);_detail=mpos.ui.screen_stack[-1][0]")
    value=helpers.wait_action(d)
    if value['label']!='Uninstall':raise RuntimeError(str(value))
    record('real_detail_versions_and_actions',value)
    d.command('_detail.install_button.send_event(lv.EVENT.CLICKED,None)')
    value=helpers.wait_action(d)
    if value['label']!='Install':raise RuntimeError(str(value))
    d.command("if store_install.read_receipt('com.example.cc_skill_smoke') is not None:raise RuntimeError('Receipt retained after uninstall')")
    record('real_uninstall_and_receipt_removal',value)
    d.command('_detail.install_button.send_event(lv.EVENT.CLICKED,None)')
    value=helpers.wait_action(d,180)
    if value['label']!='Uninstall' or 'Install failed' in value['message']:raise RuntimeError(str(value))
    output=d.command("print('BUILTIN_RECEIPT',json.dumps(store_install.read_receipt('com.example.cc_skill_smoke')))\nif os.listdir('/cache/com.micropythonos.appstore/install/stage') or os.listdir('/cache/com.micropythonos.appstore/install/backup'):raise RuntimeError('Unclean staging')")
    record('real_https_mpk_integrity_and_install_success',helpers.parse(output,'BUILTIN_RECEIPT'))
    d.command('_detail._open_button.send_event(lv.EVENT.CLICKED,None);_calc=mpos.ui.screen_stack[-1][0]')
    time.sleep(.5)
    d.command("from mpos.ui.testing import get_all_children;_matrix=next(w for w in get_all_children(lv.screen_active()) if isinstance(w,lv.buttonmatrix))")
    for index in [12,9,15,10,14]:d.command('_matrix.set_selected_button(%d);_matrix.send_event(lv.EVENT.VALUE_CHANGED,None)'%index,show=False)
    d.command("if _calc.display.get_text()!='5':raise RuntimeError('Calculation failed')\nprint('BUILTIN_CALCULATOR_LAUNCH_SUCCESS',type(_calc).__name__,_calc.display.get_text())")
    helpers.capture(d,'builtin-calculator')
    record('real_launch_arithmetic_and_return',{'activity':'CalculatorActivity','result':'5'})
    d.command("_calc.finish();_detail.finish();_store.finish()\nif _detail.install_button is not None or _store.main_screen is not None:raise RuntimeError('Destroyed widgets retained')\nprint('BUILTIN_MAIN_CHAIN_COMPLETE',type(mpos.ui.screen_stack[-1][0]).__name__)")
    record('lifecycle_and_launcher_return',True)
