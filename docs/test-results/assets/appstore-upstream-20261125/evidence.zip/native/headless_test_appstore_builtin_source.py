import micropython
micropython.opt_level(0)
import sys
sys.path.insert(0, "lib")
import lvgl as lv
lv.init()
_display = lv.display_create(320, 240)
_buffer = bytearray(320 * 24 * 2)
_display.set_buffers(_buffer, None, len(_buffer), lv.DISPLAY_RENDER_MODE.PARTIAL)
_display.set_flush_cb(lambda display, area, pixels: display.flush_ready())
from mpos import DownloadManager, DisplayMetrics
DisplayMetrics.set_resolution(320, 240)
DisplayMetrics.set_dpi(130)
async def _no_live_request(*args, **kwargs):
    raise RuntimeError("Unexpected live network in unit test")
DownloadManager.download_url = _no_live_request
import sys
sys.path.insert(0, 'lib')
try:
    import mpos; mpos.TaskManager.disable()
except Exception:
    pass
import unittest
def _mpos_asserts_ok(_ut):
    _t = _ut.TestCase()
    for _f, _a in ((_t.assertTrue, False), (_t.fail, 'self-check')):
        try:
            _f(_a)
            return False
        except AssertionError:
            pass
    return True
_mpos_asserts_work = _mpos_asserts_ok(unittest)
if not _mpos_asserts_work:
    _mpos_stripped_ut = sys.modules.pop('unittest', None)
    try:
        import unittest as _mpos_fresh_ut
    except ImportError:
        _mpos_fresh_ut = None
    if _mpos_stripped_ut is not None:
        sys.modules['unittest'] = _mpos_stripped_ut
    if (_mpos_fresh_ut is not None
            and _mpos_fresh_ut is not _mpos_stripped_ut
            and _mpos_asserts_ok(_mpos_fresh_ut)):
        for _mpos_name in dir(_mpos_fresh_ut.TestCase):
            if _mpos_name.startswith('assert') or _mpos_name == 'fail':
                setattr(_mpos_stripped_ut.TestCase, _mpos_name,
                        getattr(_mpos_fresh_ut.TestCase, _mpos_name))
        _mpos_asserts_work = _mpos_asserts_ok(unittest)
        if _mpos_asserts_work:
            print('MPOS_TEST_RUNNER: repaired stripped unittest assert methods using lib/unittest')
if not _mpos_asserts_work:
    print('MPOS_TEST_RUNNER FATAL: unittest assertions are no-ops: unittest was imported from a build with assert statements stripped (mpy-cross -O3, e.g. the frozen lib of a prod firmware), no working lib/unittest was available to repair it, and test results would be vacuously green. Use a dev build, or ensure a non-optimized lib/unittest is on sys.path.')
for _k in list(globals().keys()):
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase) and _k != 'TestCase':
                del globals()[_k]
        except Exception:
            pass
import asyncio
import sys
import unittest

sys.path.insert(0, 'builtin/apps/com.micropythonos.appstore')

from mpos import AppManager, Intent, NotificationManager, TaskManager
import appstore
import appstore_core
import store_source


class TestUpdates(unittest.TestCase):
    def setUp(self):
        asyncio.new_event_loop()
        self.saved = []
        self.replace(store_source, 'current_source', lambda: 'upystore')
        self.replace(appstore_core.AppUpdateManager, '_instance', None)
        self.manager = appstore_core.AppUpdateManager.get_instance()
        self.replace(self.manager, '_notify_updates_available', lambda: None)
        self.replace(self.manager, '_clear_notification', lambda: None)

    def replace(self, owner, name, value):
        self.saved.append((owner, name, getattr(owner, name)))
        setattr(owner, name, value)

    def tearDown(self):
        for owner, name, original in reversed(self.saved):
            setattr(owner, name, original)

    def test_update_check_retains_revision_and_source(self):
        calls = []
        async def catalog(url):
            calls.append(url)
            return [{'slug': 'com.test.a', 'name': 'A', 'version': '1.0.0', 'revision': 2, '_store_source': 'upystore', '_store_slug': 'com-test-a'}]
        self.replace(store_source, 'fetch_updates', catalog)
        self.replace(appstore_core, 'update_available', lambda *args: True)
        asyncio.get_event_loop().run_until_complete(self.manager.check_for_updates(force=True))
        self.assertEqual(calls, ['https://upystore.io/app_index.json'])
        self.assertEqual(self.manager.current_state, 'updates_available')
        self.assertEqual(self.manager.updatable_apps[0]['revision'], 2)
        self.assertEqual(self.manager.updatable_apps[0]['_store_source'], 'upystore')

    def test_update_request_error_recovers_on_retry(self):
        async def failure(url):
            raise ValueError('unavailable package metadata')
        self.replace(store_source, 'fetch_updates', failure)
        asyncio.get_event_loop().run_until_complete(self.manager.check_for_updates(force=True))
        self.assertEqual(self.manager.current_state, 'error')
        self.assertFalse(self.manager._check_in_progress)
        async def success(url):
            return []
        store_source.fetch_updates = success
        asyncio.get_event_loop().run_until_complete(self.manager.check_for_updates(force=True))
        self.assertEqual(self.manager.current_state, 'no_updates')

    def test_notification_launches_independent_updates_page(self):
        self.manager.updatable_apps = [{'fullname': 'com.test.a'}]
        self.replace(self.manager, '_update_notifications_enabled', lambda: True)
        notifications = []
        self.replace(NotificationManager, 'notify', notifications.append)
        appstore_core.AppUpdateManager._notify_updates_available(self.manager)
        self.assertEqual(len(notifications), 1)
        notification = notifications[0]
        self.assertEqual(notification.notification_id, 'appstore.updates_available')
        self.assertEqual(notification.app_fullname, 'com.micropythonos.appstore')
        self.assertEqual(notification.intent.app_fullname, 'com.micropythonos.appstore')
        self.assertEqual(notification.intent.extras['category'], 'Updates')

    def test_update_all_is_sequential_and_rechecks_after_refresh(self):
        store = appstore.AppStore()
        store._has_foreground = False
        events = []
        async def install(app):
            events.append(app['fullname'])
            await TaskManager.sleep_ms(0)
        self.replace(appstore, 'install_package', install)
        self.replace(AppManager, 'refresh_apps', lambda: events.append('refresh'))
        self.replace(self.manager, 'check_for_updates_now', lambda: events.append('recheck'))
        apps = [{'fullname': name, 'download_url': 'https://upystore.io/package.mpk'} for name in ('com.test.a', 'com.test.b')]
        asyncio.get_event_loop().run_until_complete(store._run_update_all(apps))
        self.assertEqual(events, ['com.test.a', 'com.test.b', 'refresh', 'recheck'])
        self.assertFalse(store._batch_updating)

    def test_persisted_notification_dispatch_preserves_updates_category(self):
        from mpos import Notification
        self.manager.updatable_apps = [{'fullname': 'com.test.a'}]
        self.replace(self.manager, '_update_notifications_enabled', lambda: True)
        notifications = []
        self.replace(NotificationManager, 'notify', notifications.append)
        appstore_core.AppUpdateManager._notify_updates_available(self.manager)
        notification = Notification.from_persisted_dict(notifications[0].to_persisted_dict())
        AppManager.refresh_apps()
        calls = []
        self.replace(AppManager, 'start_app', lambda fullname, intent=None, **kwargs: calls.append((fullname, intent)) or True)
        self.assertTrue(NotificationManager._dispatch_intent(notification))
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][0], 'com.micropythonos.appstore')
        self.assertIsNotNone(calls[0][1])
        self.assertEqual(calls[0][1].extras['category'], 'Updates')

    def test_pause_detaches_only_own_callback(self):
        store = appstore.AppStore()
        store._has_foreground = True
        store._stop_all_timers = lambda: None
        self.manager.set_state_callback(store._on_update_state_change)
        store.onPause(None)
        self.assertIsNone(self.manager._state_callback)
        self.assertFalse(self.manager.suppress_notifications)
        self.assertFalse(store.has_foreground())

    def test_settings_keep_icons_wip_and_notifications_without_backend_switch(self):
        store = appstore.AppStore()
        store.appFullName = 'com.micropythonos.appstore'
        store.prefs = object()
        store._icon_pipeline = 'download'
        intents = []
        store.startActivity = intents.append
        store.settings_button_tap(None)
        settings = intents[0].extras['settings']
        keys = [setting['key'] for setting in settings]
        self.assertEqual(keys, ['store_source', 'store_query', 'icon_pipeline', 'hide_wip', 'update_notifications'])

    def test_search_does_not_clear_existing_updates_or_request_background_catalog(self):
        store = appstore.AppStore()
        store._data_loaded = True
        self.manager.updatable_apps = [{'fullname': 'com.test.a'}]
        calls = []
        self.replace(self.manager, 'clear_updates_notification', lambda: calls.append('clear'))
        self.replace(self.manager, 'check_for_updates_now', lambda: calls.append('check'))
        store._store_query_changed('calculator')
        self.assertFalse(store._data_loaded)
        self.assertEqual(self.manager.updatable_apps, [{'fullname': 'com.test.a'}])
        self.assertEqual(calls, [])

    def test_category_options_include_installed_updates_and_catalog_categories(self):
        import lvgl as lv
        from mpos import App
        store = appstore.AppStore()
        store._has_foreground = True
        store._hide_wip = True
        store._wip_apps = []
        store._selected_category = 'All'
        store.apps = [App(name='A', fullname='com.test.a', category='utilities', load_icons=False)]
        screen = lv.obj()
        store.category_dropdown = lv.dropdown(screen)
        try:
            store._update_category_dropdown()
            self.assertIn('Installed', store._category_options)
            self.assertIn('Updates', store._category_options)
            self.assertTrue(any('utilities' in value.lower() for value in store._category_options))
        finally:
            screen.delete()


if __name__ == '__main__':
    unittest.main()

suite = unittest.TestSuite()
for _k in dir():
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase):
                suite.addTest(_v)
        except Exception:
            pass
if not _mpos_asserts_work:
    print('TEST WAS A FAILURE')
else:
    result = unittest.TextTestRunner().run(suite)
    print('TEST WAS A SUCCESS' if result.wasSuccessful() else 'TEST WAS A FAILURE')
