import micropython
micropython.opt_level(0)
import sys
sys.path.insert(0, "lib")
import lvgl as lv
lv.init()
_display = lv.display_create(320, 240)
_buffer = bytearray(320 * 24 * 2)
_display.set_buffers(_buffer, None, len(_buffer), lv.DISPLAY_RENDER_MODE.PARTIAL)
_display.set_flush_cb(lambda display, area, pixels: display.flush_ready())
from mpos import DownloadManager, DisplayMetrics
DisplayMetrics.set_resolution(320, 240)
DisplayMetrics.set_dpi(130)
async def _no_live_request(*args, **kwargs):
    raise RuntimeError("Unexpected live network in unit test")
DownloadManager.download_url = _no_live_request
import sys
sys.path.insert(0, 'lib')
try:
    import mpos; mpos.TaskManager.disable()
except Exception:
    pass
import unittest
def _mpos_asserts_ok(_ut):
    _t = _ut.TestCase()
    for _f, _a in ((_t.assertTrue, False), (_t.fail, 'self-check')):
        try:
            _f(_a)
            return False
        except AssertionError:
            pass
    return True
_mpos_asserts_work = _mpos_asserts_ok(unittest)
if not _mpos_asserts_work:
    _mpos_stripped_ut = sys.modules.pop('unittest', None)
    try:
        import unittest as _mpos_fresh_ut
    except ImportError:
        _mpos_fresh_ut = None
    if _mpos_stripped_ut is not None:
        sys.modules['unittest'] = _mpos_stripped_ut
    if (_mpos_fresh_ut is not None
            and _mpos_fresh_ut is not _mpos_stripped_ut
            and _mpos_asserts_ok(_mpos_fresh_ut)):
        for _mpos_name in dir(_mpos_fresh_ut.TestCase):
            if _mpos_name.startswith('assert') or _mpos_name == 'fail':
                setattr(_mpos_stripped_ut.TestCase, _mpos_name,
                        getattr(_mpos_fresh_ut.TestCase, _mpos_name))
        _mpos_asserts_work = _mpos_asserts_ok(unittest)
        if _mpos_asserts_work:
            print('MPOS_TEST_RUNNER: repaired stripped unittest assert methods using lib/unittest')
if not _mpos_asserts_work:
    print('MPOS_TEST_RUNNER FATAL: unittest assertions are no-ops: unittest was imported from a build with assert statements stripped (mpy-cross -O3, e.g. the frozen lib of a prod firmware), no working lib/unittest was available to repair it, and test results would be vacuously green. Use a dev build, or ensure a non-optimized lib/unittest is on sys.path.')
for _k in list(globals().keys()):
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase) and _k != 'TestCase':
                del globals()[_k]
        except Exception:
            pass
"""
test_appstore_uninstall_refresh.py - Verify the AppStore list picks up install
and uninstall changes made on the detail screen.

Issue #255: after uninstalling an app from its detail screen and going back,
the app was still listed under Installed. AppManager.refresh_apps() replaces
its cache with new App objects, so the object the AppStore list holds keeps
its old installed_path. AppStore.onResume() must sync installed_path from the
refreshed cache and rebuild the list when it changed.

Usage:
    python3 scripts/test_runner.py tests/test_appstore_uninstall_refresh.py
"""

import os
import sys
import ujson
import unittest

sys.path.insert(0, "builtin/apps/com.micropythonos.appstore")


class MockWidget:
    """Minimal stand-in for an lv object used by the banner code."""

    def __init__(self):
        self._flags = set()

    def add_flag(self, flag):
        self._flags.add(flag)

    def remove_flag(self, flag):
        self._flags.discard(flag)

    def has_flag(self, flag):
        return flag in self._flags

    def align(self, *args):
        pass

    def set_height(self, *args):
        pass


class TestAppStoreInstalledStateSync(unittest.TestCase):
    TEST_FULLNAME = "com.test.uninstallme"
    APP_DIR = "apps/" + TEST_FULLNAME

    def setUp(self):
        from appstore import AppStore
        from mpos import AppManager

        self._saved_app_list = list(AppManager._app_list)
        self._saved_by_fullname = dict(AppManager._by_fullname)

        self.store = AppStore()
        self.store.update_all_button = MockWidget()
        self.store.apps_list = MockWidget()
        self.store.category_dropdown = None
        self.store._update_labels = {}
        self.store._wip_apps = []
        self.store._data_loaded = True
        self.store._icon_pipeline = "none"
        self.store._icon_timer = None
        self.store._has_foreground = True

        self.build_calls = []
        self.store.create_apps_list = lambda: self.build_calls.append(1)

    def tearDown(self):
        from mpos import AppManager

        self._remove_app_dir()
        AppManager._app_list = self._saved_app_list
        AppManager._by_fullname = self._saved_by_fullname

    def _remove_app_dir(self):
        try:
            os.remove(self.APP_DIR + "/MANIFEST.JSON")
        except OSError:
            pass
        try:
            os.rmdir(self.APP_DIR)
        except OSError:
            pass

    def _create_app_dir(self):
        from mpos import AppManager, App

        try:
            os.mkdir(self.APP_DIR)
        except OSError:
            pass
        with open(self.APP_DIR + "/MANIFEST.JSON", "w") as f:
            f.write(ujson.dumps({
                "name": "UninstallMe",
                "fullname": self.TEST_FULLNAME,
                "version": "1.0",
                "category": "utilities",
            }))
        AppManager.refresh_apps()
        return AppManager.get(self.TEST_FULLNAME)

    def test_uninstall_removes_app_from_installed_list(self):
        installed = self._create_app_dir()
        self.assertIsNotNone(installed)
        self.assertEqual(installed.installed_path, self.APP_DIR)

        # The AppStore list holds the App object from the AppManager cache.
        self.store.apps = [installed]

        from mpos import AppManager
        AppManager.uninstall_app(self.TEST_FULLNAME)

        # Stale cache object still claims to be installed (the bug).
        self.assertIsNotNone(installed.installed_path)

        self.store.onResume(MockWidget())

        self.assertIsNone(
            installed.installed_path,
            "uninstalled app must lose its installed_path",
        )
        self.assertEqual(
            len(self.build_calls), 1,
            "the Installed list must be rebuilt after an uninstall",
        )

    def test_install_adds_app_to_installed_list(self):
        from mpos import App, AppManager

        store_app = App(
            name="UninstallMe",
            fullname=self.TEST_FULLNAME,
            version="1.0",
            installed_path=None,
        )
        self.store.apps = [store_app]

        self._create_app_dir()
        self.assertIsNone(store_app.installed_path)

        self.store.onResume(MockWidget())

        self.assertEqual(
            store_app.installed_path, self.APP_DIR,
            "installed app must pick up its installed_path",
        )
        self.assertEqual(
            len(self.build_calls), 1,
            "the Installed list must be rebuilt after an install",
        )

    def test_resume_without_changes_does_not_rebuild(self):
        installed = self._create_app_dir()
        self.assertIsNotNone(installed)
        self.store.apps = [installed]

        self.store.onResume(MockWidget())

        self.assertEqual(
            self.build_calls, [],
            "an unchanged list must not be rebuilt on resume",
        )
        self.assertEqual(installed.installed_path, self.APP_DIR)



suite = unittest.TestSuite()
for _k in dir():
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase):
                suite.addTest(_v)
        except Exception:
            pass
if not _mpos_asserts_work:
    print('TEST WAS A FAILURE')
else:
    result = unittest.TextTestRunner().run(suite)
    print('TEST WAS A SUCCESS' if result.wasSuccessful() else 'TEST WAS A FAILURE')
