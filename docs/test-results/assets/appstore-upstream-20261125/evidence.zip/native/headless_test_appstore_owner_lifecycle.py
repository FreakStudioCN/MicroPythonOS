import micropython
micropython.opt_level(0)
import sys
sys.path.insert(0, "lib")
import lvgl as lv
lv.init()
_display = lv.display_create(320, 240)
_buffer = bytearray(320 * 24 * 2)
_display.set_buffers(_buffer, None, len(_buffer), lv.DISPLAY_RENDER_MODE.PARTIAL)
_display.set_flush_cb(lambda display, area, pixels: display.flush_ready())
from mpos import DownloadManager, DisplayMetrics
DisplayMetrics.set_resolution(320, 240)
DisplayMetrics.set_dpi(130)
async def _no_live_request(*args, **kwargs):
    raise RuntimeError("Unexpected live network in unit test")
DownloadManager.download_url = _no_live_request
import sys
sys.path.insert(0, 'lib')
try:
    import mpos; mpos.TaskManager.disable()
except Exception:
    pass
import unittest
def _mpos_asserts_ok(_ut):
    _t = _ut.TestCase()
    for _f, _a in ((_t.assertTrue, False), (_t.fail, 'self-check')):
        try:
            _f(_a)
            return False
        except AssertionError:
            pass
    return True
_mpos_asserts_work = _mpos_asserts_ok(unittest)
if not _mpos_asserts_work:
    _mpos_stripped_ut = sys.modules.pop('unittest', None)
    try:
        import unittest as _mpos_fresh_ut
    except ImportError:
        _mpos_fresh_ut = None
    if _mpos_stripped_ut is not None:
        sys.modules['unittest'] = _mpos_stripped_ut
    if (_mpos_fresh_ut is not None
            and _mpos_fresh_ut is not _mpos_stripped_ut
            and _mpos_asserts_ok(_mpos_fresh_ut)):
        for _mpos_name in dir(_mpos_fresh_ut.TestCase):
            if _mpos_name.startswith('assert') or _mpos_name == 'fail':
                setattr(_mpos_stripped_ut.TestCase, _mpos_name,
                        getattr(_mpos_fresh_ut.TestCase, _mpos_name))
        _mpos_asserts_work = _mpos_asserts_ok(unittest)
        if _mpos_asserts_work:
            print('MPOS_TEST_RUNNER: repaired stripped unittest assert methods using lib/unittest')
if not _mpos_asserts_work:
    print('MPOS_TEST_RUNNER FATAL: unittest assertions are no-ops: unittest was imported from a build with assert statements stripped (mpy-cross -O3, e.g. the frozen lib of a prod firmware), no working lib/unittest was available to repair it, and test results would be vacuously green. Use a dev build, or ensure a non-optimized lib/unittest is on sys.path.')
for _k in list(globals().keys()):
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase) and _k != 'TestCase':
                del globals()[_k]
        except Exception:
            pass
import asyncio
import sys
import unittest

sys.path.insert(0, 'builtin/apps/com.micropythonos.appstore')

from mpos import App, TaskManager
import appstore
import appstore_core
import store_source


class TestCoexist(unittest.TestCase):
    def test_store_object_is_separate_from_global_app(self):
        original = App(name='Installed', fullname='com.test.coexist', version='1.0.0', installed_path='apps/com.test.coexist', load_icons=False)
        copied = appstore.AppStore._copy_installed_app(original)
        self.assertFalse(copied is original)
        store_source.attach(copied, {'version': '2.0.0', 'publisher': 'Remote', '_store_source': 'upystore'})
        self.assertEqual(original.version, '1.0.0')
        self.assertFalse(hasattr(original, '_store_source'))
        self.assertEqual(copied.installed_path, original.installed_path)

    def test_pending_deeplink_waits_while_paused(self):
        store = appstore.AppStore()
        store._has_foreground = False
        store._pending_deeplink = 'com.test.coexist'
        app = type('App', (), {'fullname': 'com.test.coexist'})()
        store.apps = [app]
        store._wip_apps = []
        calls = []
        store.show_app_detail = calls.append
        store._resolve_pending_deeplink()
        self.assertEqual(calls, [])
        self.assertEqual(store._pending_deeplink, app.fullname)
        store._has_foreground = True
        store._resolve_pending_deeplink()
        self.assertEqual(calls, [app])
        self.assertIsNone(store._pending_deeplink)

    def test_destroy_discards_pending_navigation(self):
        store = appstore.AppStore()
        store.apps = []
        store._pending_deeplink = 'com.test.coexist'
        store.onDestroy(None)
        self.assertIsNone(store._pending_deeplink)

    def test_service_start_is_idempotent(self):
        manager = appstore_core.AppUpdateManager()
        events = []
        class Connectivity:
            def register_callback(self, callback):
                events.append('register')
            def unregister_callback(self, callback):
                events.append('unregister')
        connectivity = Connectivity()
        original_get = appstore_core.ConnectivityManager.get
        original_task = TaskManager.create_task
        tasks = []
        appstore_core.ConnectivityManager.get = lambda: connectivity
        TaskManager.create_task = tasks.append
        try:
            manager.start()
            manager.start()
            self.assertEqual(events, ['register'])
            self.assertEqual(len(tasks), 1)
            manager.stop()
            self.assertEqual(events, ['register', 'unregister'])
        finally:
            manager.stop()
            appstore_core.ConnectivityManager.get = original_get
            TaskManager.create_task = original_task

    def test_notification_identity_is_separate(self):
        self.assertEqual(appstore_core.AppUpdateManager.NOTIFICATION_ID, 'appstore.updates_available')
        self.assertEqual(appstore_core.AppUpdateManager.ICON_PATH, 'M:builtin/apps/com.micropythonos.appstore/icon_64x64.png')


if __name__ == '__main__':
    unittest.main()

suite = unittest.TestSuite()
for _k in dir():
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase):
                suite.addTest(_v)
        except Exception:
            pass
if not _mpos_asserts_work:
    print('TEST WAS A FAILURE')
else:
    result = unittest.TextTestRunner().run(suite)
    print('TEST WAS A SUCCESS' if result.wasSuccessful() else 'TEST WAS A FAILURE')
