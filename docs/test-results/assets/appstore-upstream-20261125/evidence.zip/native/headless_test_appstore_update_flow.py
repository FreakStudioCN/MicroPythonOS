import micropython
micropython.opt_level(0)
import sys
sys.path.insert(0, "lib")
import lvgl as lv
lv.init()
_display = lv.display_create(320, 240)
_buffer = bytearray(320 * 24 * 2)
_display.set_buffers(_buffer, None, len(_buffer), lv.DISPLAY_RENDER_MODE.PARTIAL)
_display.set_flush_cb(lambda display, area, pixels: display.flush_ready())
from mpos import DownloadManager, DisplayMetrics
DisplayMetrics.set_resolution(320, 240)
DisplayMetrics.set_dpi(130)
async def _no_live_request(*args, **kwargs):
    raise RuntimeError("Unexpected live network in unit test")
DownloadManager.download_url = _no_live_request
import sys
sys.path.insert(0, 'lib')
try:
    import mpos; mpos.TaskManager.disable()
except Exception:
    pass
import unittest
def _mpos_asserts_ok(_ut):
    _t = _ut.TestCase()
    for _f, _a in ((_t.assertTrue, False), (_t.fail, 'self-check')):
        try:
            _f(_a)
            return False
        except AssertionError:
            pass
    return True
_mpos_asserts_work = _mpos_asserts_ok(unittest)
if not _mpos_asserts_work:
    _mpos_stripped_ut = sys.modules.pop('unittest', None)
    try:
        import unittest as _mpos_fresh_ut
    except ImportError:
        _mpos_fresh_ut = None
    if _mpos_stripped_ut is not None:
        sys.modules['unittest'] = _mpos_stripped_ut
    if (_mpos_fresh_ut is not None
            and _mpos_fresh_ut is not _mpos_stripped_ut
            and _mpos_asserts_ok(_mpos_fresh_ut)):
        for _mpos_name in dir(_mpos_fresh_ut.TestCase):
            if _mpos_name.startswith('assert') or _mpos_name == 'fail':
                setattr(_mpos_stripped_ut.TestCase, _mpos_name,
                        getattr(_mpos_fresh_ut.TestCase, _mpos_name))
        _mpos_asserts_work = _mpos_asserts_ok(unittest)
        if _mpos_asserts_work:
            print('MPOS_TEST_RUNNER: repaired stripped unittest assert methods using lib/unittest')
if not _mpos_asserts_work:
    print('MPOS_TEST_RUNNER FATAL: unittest assertions are no-ops: unittest was imported from a build with assert statements stripped (mpy-cross -O3, e.g. the frozen lib of a prod firmware), no working lib/unittest was available to repair it, and test results would be vacuously green. Use a dev build, or ensure a non-optimized lib/unittest is on sys.path.')
for _k in list(globals().keys()):
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase) and _k != 'TestCase':
                del globals()[_k]
        except Exception:
            pass
"""
Tests for the AppStore "updates available" pipeline.

Covers the six serious gaps from tests/plans/app_updates.md:
1. Boot service wiring
2. check_for_updates() state machine and network error handling
3. Notification posting and click->launch
4. _run_update_all() sequential per-app update
5. Post-update UI cleanup
6. suppress_notifications toggle
"""

import sys
import unittest

sys.path.insert(0, "builtin/apps/com.micropythonos.appstore")

import appstore as appstore_module
import store_source as store_source_module

# ---------------------------------------------------------------------------
# LVGL constants (available even when display is uninitialised)
# ---------------------------------------------------------------------------

HIDDEN_FLAG = 0x0001
DISABLED_STATE = 0x0080


# ---------------------------------------------------------------------------
# Shared mocks
# ---------------------------------------------------------------------------

class MockLabel:
    def __init__(self):
        self._text = ""
        self._flags = set()
        self._states = set()

    def set_text(self, text):
        self._text = text

    def add_flag(self, flag):
        self._flags.add(flag)

    def remove_flag(self, flag):
        self._flags.discard(flag)

    def has_flag(self, flag):
        return flag in self._flags

    def add_state(self, state):
        self._states.add(state)

    def remove_state(self, state):
        self._states.discard(state)


class MockPrefs:
    """Mimics SharedPreferences(app_id) — first arg is app_id, not data."""

    def __init__(self, app_id, filename=None):
        self._data = {}

    def get_string(self, key, default=None):
        return "badgehub" if key == "store_source" else self._data.get(key, default)

    def edit(self):
        return self

    def put_string(self, key, value):
        self._data[key] = value
        return self

    def commit(self):
        pass


class MockPrefsNotificationsOff(MockPrefs):
    def get_string(self, key, default=None):
        if key == "update_notifications":
            return "false"
        return super().get_string(key, default)


class MockConnectivityManager:
    def __init__(self, online=True):
        self._online = online
        self._callbacks = []

    def is_online(self):
        return self._online

    def register_callback(self, cb):
        self._callbacks.append(cb)

    def unregister_callback(self, cb):
        if cb in self._callbacks:
            self._callbacks.remove(cb)

    @classmethod
    def get(cls):
        if not hasattr(cls, "_inst"):
            cls._inst = cls()
        return cls._inst

    @classmethod
    def reset_instance(cls):
        if hasattr(cls, "_inst"):
            delattr(cls, "_inst")


class MockDropdown:
    """Captures LVGL dropdown set_options calls."""

    def __init__(self):
        self._options = ""
        self._selected = 0

    def set_options(self, text):
        self._options = text

    def get_selected(self):
        return self._selected

    def set_selected(self, idx):
        self._selected = idx


class _MockAUM:
    """Mock AppUpdateManager with controllable updatable_apps."""

    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        cls._instance = None

    def __init__(self):
        self.updatable_apps = []
        self.current_state = "idle"
        self._state_callback = None
        self._suppress_notifications = False

    def set_state_callback(self, cb):
        self._state_callback = cb

    def clear_state_callback(self):
        self._state_callback = None

    def check_for_updates_now(self, index_url=None):
        pass

    @property
    def suppress_notifications(self):
        return self._suppress_notifications

    @suppress_notifications.setter
    def suppress_notifications(self, value):
        self._suppress_notifications = bool(value)


# ---------------------------------------------------------------------------
# Gap #1: Boot service wiring
# ---------------------------------------------------------------------------

class TestBootServiceWiring(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def test_onStart_calls_app_update_manager_start(self):
        import appstore_boot_service, appstore_core

        start_calls = []

        class _MockAUM:
            _instance = None

            @classmethod
            def get_instance(cls):
                if cls._instance is None:
                    cls._instance = cls()
                return cls._instance

            def start(self):
                start_calls.append(True)

            def stop(self):
                pass

        orig_core = appstore_core.AppUpdateManager
        orig_svc = appstore_boot_service.AppUpdateManager
        appstore_core.AppUpdateManager = _MockAUM
        appstore_boot_service.AppUpdateManager = _MockAUM
        try:
            svc = appstore_boot_service.AppStoreService()
            svc.onStart(None)
            self.assertEqual(len(start_calls), 1)
        finally:
            appstore_core.AppUpdateManager = orig_core
            appstore_boot_service.AppUpdateManager = orig_svc

    def test_onDestroy_calls_app_update_manager_stop(self):
        import appstore_boot_service, appstore_core

        stop_calls = []

        class _MockAUM:
            _instance = None

            @classmethod
            def get_instance(cls):
                if cls._instance is None:
                    cls._instance = cls()
                return cls._instance

            def start(self):
                pass

            def stop(self):
                stop_calls.append(True)

        orig_core = appstore_core.AppUpdateManager
        orig_svc = appstore_boot_service.AppUpdateManager
        appstore_core.AppUpdateManager = _MockAUM
        appstore_boot_service.AppUpdateManager = _MockAUM
        try:
            svc = appstore_boot_service.AppStoreService()
            svc.onDestroy()
            self.assertEqual(len(stop_calls), 1)
        finally:
            appstore_core.AppUpdateManager = orig_core
            appstore_boot_service.AppUpdateManager = orig_svc


# ---------------------------------------------------------------------------
# Gap #2: check_for_updates() state machine + network errors
# ---------------------------------------------------------------------------

class TestAppUpdateManagerCheck(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def _patch_aum(self):
        import appstore_core
        from appstore_core import AppUpdateManager, AppUpdateState
        import mpos

        MockConnectivityManager.reset_instance()
        orig_cm = appstore_core.ConnectivityManager
        appstore_core.ConnectivityManager = MockConnectivityManager

        orig_sp = appstore_core.SharedPreferences
        appstore_core.SharedPreferences = MockPrefs
        self._source_prefs = store_source_module.SharedPreferences
        store_source_module.SharedPreferences = MockPrefs

        notify_calls = []
        cancel_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        def _fake_cancel(nid):
            cancel_calls.append(nid)

        orig_notify = mpos.NotificationManager.notify
        orig_cancel = mpos.NotificationManager.cancel
        mpos.NotificationManager.notify = _fake_notify
        mpos.NotificationManager.cancel = _fake_cancel

        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum._suppress_notifications = True

        return {
            "aum": aum,
            "orig_cm": orig_cm,
            "orig_sp": orig_sp,
            "orig_notify": orig_notify,
            "orig_cancel": orig_cancel,
            "notify_calls": notify_calls,
            "cancel_calls": cancel_calls,
            "appstore_core": appstore_core,
            "AppUpdateState": AppUpdateState,
        }

    def _unpatch(self, ctx):
        import mpos
        ctx["appstore_core"].ConnectivityManager = ctx["orig_cm"]
        ctx["appstore_core"].SharedPreferences = ctx["orig_sp"]
        store_source_module.SharedPreferences = self._source_prefs
        mpos.NotificationManager.notify = ctx["orig_notify"]
        mpos.NotificationManager.cancel = ctx["orig_cancel"]
        ctx["appstore_core"].AppUpdateManager._instance = None
        MockConnectivityManager.reset_instance()

    def _mock_download_url(self, return_value=None, exception=None):
        import mpos.net.download_manager as dm

        async def _dl(url):
            if exception:
                raise exception
            return return_value

        orig = dm.DownloadManager.download_url
        dm.DownloadManager.download_url = staticmethod(_dl)
        return orig

    def _mock_is_update_available(self, results):
        import mpos
        orig = mpos.AppManager.is_update_available

        def _fake(fullname, version):
            return results.get(fullname, False)

        mpos.AppManager.is_update_available = staticmethod(_fake)
        return orig

    def test_check_for_updates_finds_updates(self):
        ctx = self._patch_aum()
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
                {"slug": "com.test.b", "name": "TestB", "version": "1.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True, "com.test.b": False})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE)
                self.assertEqual(len(ctx["aum"].updatable_apps), 1)
                self.assertEqual(ctx["aum"].updatable_apps[0]["fullname"], "com.test.a")
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_finds_no_updates(self):
        ctx = self._patch_aum()
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "1.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": False})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].NO_UPDATES)
                self.assertEqual(len(ctx["aum"].updatable_apps), 0)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_badgehub_format(self):
        ctx = self._patch_aum()
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.alpha", "name": "Alpha", "version": "2.0"},
                {"slug": "com.test.beta", "name": "Beta", "version": "1.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.alpha": True, "com.test.beta": False})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE)
                self.assertEqual(len(ctx["aum"].updatable_apps), 1)
                self.assertEqual(ctx["aum"].updatable_apps[0]["fullname"], "com.test.alpha")
                self.assertEqual(ctx["aum"].updatable_apps[0]["version"], "2.0")
                self.assertIsNone(ctx["aum"].updatable_apps[0]["download_url"])
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_network_error_becomes_waiting_wifi(self):
        ctx = self._patch_aum()
        try:
            orig_dl = self._mock_download_url(exception=OSError(-113, "ECONNABORTED"))
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].WAITING_WIFI)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_non_network_error_becomes_error(self):
        ctx = self._patch_aum()
        try:
            orig_dl = self._mock_download_url(exception=ValueError("bad url"))
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].ERROR)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_json_parse_error(self):
        ctx = self._patch_aum()
        try:
            orig_dl = self._mock_download_url(return_value="not json {{{")
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].ERROR)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
        finally:
            self._unpatch(ctx)

    def test_check_in_progress_prevents_reentry(self):
        ctx = self._patch_aum()
        try:
            ctx["aum"]._check_in_progress = True
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(ctx["aum"].check_for_updates())
            self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].IDLE)
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_cooldown_blocks_recheck(self):
        ctx = self._patch_aum()
        try:
            import time
            ctx["aum"]._last_check_ts = time.ticks_ms()
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(ctx["aum"].check_for_updates())
            self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].IDLE,
                             "cooldown should block recheck within 60s")
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_force_bypasses_cooldown(self):
        ctx = self._patch_aum()
        try:
            import json, time
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
            ])
            ctx["aum"]._last_check_ts = time.ticks_ms()
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates(force=True))
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE,
                                 "force=True should bypass cooldown and complete the check")
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_now_uses_force(self):
        ctx = self._patch_aum()
        try:
            ctx["aum"]._check_in_progress = False
            import time
            ctx["aum"]._last_check_ts = time.ticks_ms()
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True})
            import mpos
            tasks = []
            orig_ct = mpos.TaskManager.create_task

            def _capture_and_await(coro):
                tasks.append(coro)
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(coro)

            mpos.TaskManager.create_task = _capture_and_await
            try:
                ctx["aum"].check_for_updates_now()
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE,
                                 "check_for_updates_now should force-bypass cooldown")
            finally:
                mpos.TaskManager.create_task = orig_ct
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos as mp
                mp.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_check_for_updates_now_skips_when_check_in_progress(self):
        ctx = self._patch_aum()
        try:
            ctx["aum"]._check_in_progress = True
            import mpos
            tasks = []
            orig_ct = mpos.TaskManager.create_task

            def _capture(coro):
                tasks.append(coro)

            mpos.TaskManager.create_task = _capture
            try:
                ctx["aum"].check_for_updates_now()
                self.assertEqual(len(tasks), 0)
            finally:
                mpos.TaskManager.create_task = orig_ct
        finally:
            self._unpatch(ctx)

    def test_state_transitions_through_checking(self):
        ctx = self._patch_aum()
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
            ])
            states_seen = []

            def _capture_state(state):
                states_seen.append(state)

            ctx["aum"].set_state_callback(_capture_state)
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertIn(ctx["AppUpdateState"].CHECKING_UPDATES, states_seen)
                self.assertEqual(states_seen[-1], ctx["AppUpdateState"].UPDATES_AVAILABLE)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_network_changed_offline_while_checking(self):
        ctx = self._patch_aum()
        try:
            ctx["aum"].current_state = ctx["AppUpdateState"].CHECKING_UPDATES
            ctx["aum"]._network_changed(False)
            self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].WAITING_WIFI)
        finally:
            self._unpatch(ctx)

    def test_network_changed_online_from_waiting_triggers_check(self):
        ctx = self._patch_aum()
        try:
            import mpos
            tasks = []
            orig_ct = mpos.TaskManager.create_task

            def _capture(coro):
                tasks.append(coro)

            mpos.TaskManager.create_task = _capture
            try:
                ctx["aum"].current_state = ctx["AppUpdateState"].WAITING_WIFI
                ctx["aum"]._network_changed(True)
                self.assertEqual(len(tasks), 1)
            finally:
                mpos.TaskManager.create_task = orig_ct
        finally:
            self._unpatch(ctx)

    def test_network_changed_online_from_error_triggers_check(self):
        ctx = self._patch_aum()
        try:
            import mpos
            tasks = []
            orig_ct = mpos.TaskManager.create_task

            def _capture(coro):
                tasks.append(coro)

            mpos.TaskManager.create_task = _capture
            try:
                ctx["aum"].current_state = ctx["AppUpdateState"].ERROR
                ctx["aum"]._network_changed(True)
                self.assertEqual(len(tasks), 1)
            finally:
                mpos.TaskManager.create_task = orig_ct
        finally:
            self._unpatch(ctx)


# ---------------------------------------------------------------------------
# Gaps #3 and #6: Notification posting + suppress_notifications toggle
# ---------------------------------------------------------------------------

class TestAppUpdateManagerNotifications(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def tearDown(self):
        MockConnectivityManager.reset_instance()

    def test_notify_updates_available_posts_correct_notification(self):
        import appstore_core
        from appstore_core import AppUpdateManager
        import mpos

        orig_notify = mpos.NotificationManager.notify
        notify_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        mpos.NotificationManager.notify = _fake_notify
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum.updatable_apps = [
            {"fullname": "com.test.a", "name": "TestA"},
            {"fullname": "com.test.b", "name": "TestB"},
        ]
        try:
            aum._notify_updates_available()
            self.assertEqual(len(notify_calls), 1)
            n = notify_calls[0]
            self.assertEqual(n.notification_id, "appstore.updates_available")
            self.assertEqual(n.title, "App updates available")
            self.assertEqual(n.text, "2 apps can be updated")
            self.assertTrue(n.auto_cancel)
            self.assertEqual(n.intent.app_fullname, "com.micropythonos.appstore")
        finally:
            mpos.NotificationManager.notify = orig_notify
            AppUpdateManager._instance = None

    def test_notify_updates_available_singular(self):
        import appstore_core
        from appstore_core import AppUpdateManager
        import mpos

        orig_notify = mpos.NotificationManager.notify
        notify_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        mpos.NotificationManager.notify = _fake_notify
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum.updatable_apps = [{"fullname": "com.test.a", "name": "TestA"}]
        try:
            aum._notify_updates_available()
            self.assertEqual(len(notify_calls), 1)
            self.assertEqual(notify_calls[0].text, "1 app can be updated")
        finally:
            mpos.NotificationManager.notify = orig_notify
            AppUpdateManager._instance = None

    def test_suppress_notifications_blocks_posting(self):
        import appstore_core
        from appstore_core import AppUpdateManager
        import mpos

        orig_notify = mpos.NotificationManager.notify
        notify_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        mpos.NotificationManager.notify = _fake_notify
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum._suppress_notifications = True
        aum.updatable_apps = [{"fullname": "com.test.a", "name": "TestA"}]
        try:
            aum._notify_updates_available()
            self.assertEqual(len(notify_calls), 0)
        finally:
            mpos.NotificationManager.notify = orig_notify
            AppUpdateManager._instance = None

    def test_clear_notification_calls_cancel(self):
        import appstore_core
        from appstore_core import AppUpdateManager
        import mpos

        orig_cancel = mpos.NotificationManager.cancel
        cancel_calls = []

        def _fake_cancel(nid):
            cancel_calls.append(nid)

        mpos.NotificationManager.cancel = _fake_cancel
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        try:
            aum._clear_notification()
            self.assertEqual(cancel_calls, ["appstore.updates_available"])
        finally:
            mpos.NotificationManager.cancel = orig_cancel
            AppUpdateManager._instance = None

    def test_suppress_notifications_property(self):
        import appstore_core
        from appstore_core import AppUpdateManager
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        try:
            self.assertFalse(aum.suppress_notifications)
            aum.suppress_notifications = True
            self.assertTrue(aum.suppress_notifications)
            aum.suppress_notifications = 1
            self.assertTrue(aum.suppress_notifications)
            aum.suppress_notifications = False
            self.assertFalse(aum.suppress_notifications)
        finally:
            AppUpdateManager._instance = None


# ---------------------------------------------------------------------------
# Gap #4: _run_update_all() sequential per-app update
# ---------------------------------------------------------------------------

class TestAppUpdateRunAll(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def _make_store(self):
        import mpos
        from appstore import AppStore

        self._orig_refresh = mpos.AppManager.refresh_apps
        self._orig_dl = appstore_module.install_package
        self.refresh_calls = []
        self.install_calls = []

        mpos.AppManager.refresh_apps = lambda: self.refresh_calls.append(True)

        async def _fake_dl(app_data, **kwargs):
            url, fullname = app_data["download_url"], app_data["fullname"]
            self.install_calls.append((url, fullname))

        appstore_module.install_package = _fake_dl

        store = AppStore()
        store.prefs = MockPrefs(None)
        store.please_wait_label = MockLabel()
        store._refresh_in_progress = False
        store.update_all_button = MockLabel()
        store.update_all_label = MockLabel()
        store.main_screen = MockLabel()
        store.apps = []
        store._has_foreground = True
        return store

    def tearDown(self):
        import mpos
        mpos.AppManager.refresh_apps = getattr(self, "_orig_refresh", lambda: None)
        appstore_module.install_package = getattr(self, "_orig_dl", lambda *a, **kw: None)

    def test_run_update_all_installs_each_app_in_order(self):
        store = self._make_store()
        apps = [
            {"fullname": "com.test.a", "name": "AppA", "download_url": "http://x/a.mpk"},
            {"fullname": "com.test.b", "name": "AppB", "download_url": "http://x/b.mpk"},
        ]
        import asyncio
        loop = asyncio.get_event_loop()
        loop.run_until_complete(store._run_update_all(apps))
        self.assertEqual(len(self.install_calls), 2)
        self.assertEqual(self.install_calls[0], ("http://x/a.mpk", "com.test.a"))
        self.assertEqual(self.install_calls[1], ("http://x/b.mpk", "com.test.b"))
        self.assertTrue(self.refresh_calls)

    def test_run_update_all_skips_apps_without_fullname(self):
        store = self._make_store()
        apps = [
            {"name": "NoFullname", "download_url": "http://x/a.mpk"},
            {"fullname": "com.test.b", "name": "AppB", "download_url": "http://x/b.mpk"},
        ]
        import asyncio
        loop = asyncio.get_event_loop()
        loop.run_until_complete(store._run_update_all(apps))
        self.assertEqual(len(self.install_calls), 1)
        self.assertEqual(self.install_calls[0][1], "com.test.b")

    def test_run_update_all_skips_apps_without_download_url(self):
        store = self._make_store()
        apps = [
            {"fullname": "com.test.a", "name": "AppA", "_store_source": "badgehub"},
        ]
        import asyncio
        loop = asyncio.get_event_loop()
        loop.run_until_complete(store._run_update_all(apps))
        self.assertEqual(len(self.install_calls), 0)

    def test_run_update_all_fetches_badgehub_details(self):
        import mpos.net.download_manager as dm

        store = self._make_store()
        apps = [
            {"fullname": "com.test.alpha", "name": "Alpha", "_store_source": "badgehub"},
        ]
        orig_dl = dm.DownloadManager.download_url

        async def _fake_details(url):
            import json
            return json.dumps({
                "version": {
                    "revision": 5,
                    "app_metadata": {"version": "2.0", "author": "Test"},
                    "files": [{
                        "name": "com.test.alpha_2.0",
                        "ext": ".mpk",
                        "full_path": "com.test.alpha_2.0.mpk",
                        "url": "http://badgehub.eu/file.mpk",
                        "size_of_content": 1000,
                    }],
                }
            })

        dm.DownloadManager.download_url = staticmethod(_fake_details)
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(store._run_update_all(apps))
            self.assertEqual(len(self.install_calls), 1)
            self.assertEqual(self.install_calls[0][0], "http://badgehub.eu/file.mpk")
        finally:
            dm.DownloadManager.download_url = orig_dl

    def test_run_update_all_handles_install_failure(self):
        import mpos

        store = self._make_store()
        appstore_module.install_package = self._orig_dl
        fail_calls = []

        async def _fail_first(app_data, **kwargs):
            url, fullname = app_data["download_url"], app_data["fullname"]
            fail_calls.append(fullname)
            if fullname == "com.test.a":
                raise OSError("download failed")
            self.install_calls.append((url, fullname))

        appstore_module.install_package = _fail_first

        apps = [
            {"fullname": "com.test.a", "name": "AppA", "download_url": "http://x/a.mpk"},
            {"fullname": "com.test.b", "name": "AppB", "download_url": "http://x/b.mpk"},
        ]
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(store._run_update_all(apps))
            self.assertEqual(len(self.install_calls), 1)
            self.assertEqual(self.install_calls[0][1], "com.test.b")
            self.assertIn("com.test.a", fail_calls)
        finally:
            appstore_module.install_package = self._orig_dl

    def test_run_update_all_disables_button_during_update(self):
        import mpos

        store = self._make_store()
        button_states_during = []

        async def _capture_state(app_data, **kwargs):
            button_states_during.append(bool(store.update_all_button._states))

        appstore_module.install_package = _capture_state
        try:
            apps = [
                {"fullname": "com.test.a", "name": "AppA", "download_url": "http://x/a.mpk"},
            ]
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(store._run_update_all(apps))
            self.assertTrue(button_states_during, "button should be disabled during install")
            self.assertTrue(button_states_during[0], "button._states should be non-empty (disabled)")
        finally:
            appstore_module.install_package = self._orig_dl

    def test_run_update_all_handles_out_of_space(self):
        import mpos

        store = self._make_store()
        appstore_module.install_package = self._orig_dl

        async def _fail_space(app_data, **kwargs):
            raise OSError("Not enough free space available")

        appstore_module.install_package = _fail_space

        apps = [
            {"fullname": "com.test.a", "name": "AppA", "download_url": "http://x/a.mpk"},
        ]
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            loop.run_until_complete(store._run_update_all(apps))
            # button should be re-enabled after the loop
            self.assertEqual(len(store.update_all_button._states), 0)
            # label should show space error
            self.assertIn("Not enough space", store.update_all_label._text)
        finally:
            appstore_module.install_package = self._orig_dl


# ---------------------------------------------------------------------------
# Gap #4b: _run_update_all must force-clear stale updatable_apps after installs
# ---------------------------------------------------------------------------

class TestAppUpdateRunAllClearsUpdatableApps(unittest.TestCase):
    def setUp(self):
        import asyncio
        import mpos
        import appstore_core

        asyncio.new_event_loop()

        MockConnectivityManager.reset_instance()
        self._orig_cm = appstore_core.ConnectivityManager
        appstore_core.ConnectivityManager = MockConnectivityManager

        self._orig_sp = appstore_core.SharedPreferences
        appstore_core.SharedPreferences = MockPrefs
        self._source_prefs = store_source_module.SharedPreferences
        store_source_module.SharedPreferences = MockPrefs

        notify_calls = []
        cancel_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        def _fake_cancel(nid):
            cancel_calls.append(nid)

        self._orig_notify = mpos.NotificationManager.notify
        self._orig_cancel = mpos.NotificationManager.cancel
        mpos.NotificationManager.notify = _fake_notify
        mpos.NotificationManager.cancel = _fake_cancel
        self._notify_calls = notify_calls
        self._cancel_calls = cancel_calls

        self._orig_dl = appstore_module.install_package
        self._install_calls = []

        async def _fake_dl(app_data, **kwargs):
            url, fullname = app_data["download_url"], app_data["fullname"]
            self._install_calls.append((url, fullname))

        appstore_module.install_package = _fake_dl

        self._orig_refresh = mpos.AppManager.refresh_apps
        self._refresh_calls = []
        mpos.AppManager.refresh_apps = lambda: self._refresh_calls.append(True)

        self.tasks_created = []
        self._orig_create_task = mpos.TaskManager.create_task

        def _capture_task(coro):
            self.tasks_created.append(coro)

        mpos.TaskManager.create_task = _capture_task

        appstore_core.AppUpdateManager._instance = None
        self.aum = appstore_core.AppUpdateManager.get_instance()
        self.aum._suppress_notifications = True

    def tearDown(self):
        import mpos
        import appstore_core

        appstore_module.install_package = self._orig_dl
        mpos.AppManager.refresh_apps = self._orig_refresh
        mpos.TaskManager.create_task = self._orig_create_task
        mpos.NotificationManager.notify = self._orig_notify
        mpos.NotificationManager.cancel = self._orig_cancel

        appstore_core.ConnectivityManager = self._orig_cm
        appstore_core.SharedPreferences = self._orig_sp
        store_source_module.SharedPreferences = self._source_prefs
        appstore_core.AppUpdateManager._instance = None
        MockConnectivityManager.reset_instance()

    def _make_store(self):
        from appstore import AppStore

        store = AppStore()
        store.prefs = MockPrefs(None)
        store.please_wait_label = MockLabel()
        store._refresh_in_progress = False
        store.update_all_button = MockLabel()
        store.update_all_label = MockLabel()
        store.main_screen = MockLabel()
        store.apps = []
        store._update_labels = {}
        store._wip_apps = []
        store._has_foreground = True
        return store

    def test_run_update_all_forces_clear_of_updatable_apps(self):
        import mpos.net.download_manager as dm
        import json
        import asyncio
        import mpos

        store = self._make_store()

        store.refresh_list = lambda: None

        index_json = json.dumps([])

        async def _fake_download(url):
            return index_json

        orig_download = dm.DownloadManager.download_url
        dm.DownloadManager.download_url = staticmethod(_fake_download)

        orig_iav = mpos.AppManager.is_update_available
        mpos.AppManager.is_update_available = staticmethod(lambda fn, v: False)

        self.aum.updatable_apps = [
            {"fullname": "com.test.a", "name": "TestA", "download_url": "http://x/a.mpk"},
        ]
        self.aum.current_state = __import__("appstore_core").AppUpdateState.UPDATES_AVAILABLE

        check_tasks = []
        mpos.TaskManager.create_task = lambda c: check_tasks.append(c)

        try:
            loop = asyncio.get_event_loop()
            loop.run_until_complete(store._run_update_all([
                {"fullname": "com.test.a", "name": "TestA", "download_url": "http://x/a.mpk"},
            ]))

            self.assertTrue(self._refresh_calls, "AppManager.refresh_apps must be called")

            for task in check_tasks:
                loop.run_until_complete(task)

            self.assertEqual(
                len(self.aum.updatable_apps),
                0,
                "updatable_apps must be cleared after all updates are installed (force recheck)",
            )
        finally:
            dm.DownloadManager.download_url = orig_download
            mpos.AppManager.is_update_available = orig_iav


# ---------------------------------------------------------------------------
# Gap #5: Post-update UI cleanup
# ---------------------------------------------------------------------------

class TestAppUpdatePostUpdate(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def _make_store(self):
        from appstore import AppStore

        store = AppStore()
        store.prefs = MockPrefs(None)
        store.please_wait_label = MockLabel()
        store._refresh_in_progress = False
        store.update_all_button = MockLabel()
        store.update_all_label = MockLabel()
        store.main_screen = MockLabel()
        store.apps = []
        store._update_labels = {}
        store._has_foreground = True
        return store

    def test_sync_update_banner_shows_button_when_updates_available(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        store._sync_update_banner(AppUpdateState.UPDATES_AVAILABLE, [
            {"fullname": "com.test.a", "name": "A"},
            {"fullname": "com.test.b", "name": "B"},
        ])
        self.assertEqual(store.update_all_label._text, "Update 2 Apps")
        self.assertFalse(store.update_all_button.has_flag(HIDDEN_FLAG))

    def test_sync_update_banner_shows_singular(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        store._sync_update_banner(AppUpdateState.UPDATES_AVAILABLE, [
            {"fullname": "com.test.a", "name": "A"},
        ])
        self.assertEqual(store.update_all_label._text, "Update 1 App")

    def test_sync_update_banner_hides_button_when_no_updates(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        store._sync_update_banner(AppUpdateState.UPDATES_AVAILABLE, [{"fullname": "com.test.a", "name": "A"}])
        self.assertFalse(store.update_all_button.has_flag(HIDDEN_FLAG))
        store._sync_update_banner(AppUpdateState.NO_UPDATES, [])
        self.assertTrue(store.update_all_button.has_flag(HIDDEN_FLAG))

    def test_sync_update_banner_hides_button_for_all_other_states(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        # first show the button
        store._sync_update_banner(AppUpdateState.UPDATES_AVAILABLE, [{"fullname": "com.test.a", "name": "A"}])
        for state in [AppUpdateState.IDLE, AppUpdateState.CHECKING_UPDATES,
                       AppUpdateState.NO_UPDATES, AppUpdateState.ERROR,
                       AppUpdateState.WAITING_WIFI]:
            store._sync_update_banner(state, [])
            self.assertTrue(store.update_all_button.has_flag(HIDDEN_FLAG),
                            "button should be hidden for state %s" % state)
            # re-show for next iteration
            store.update_all_button._flags.discard(HIDDEN_FLAG)

    def test_sync_update_banner_shows_per_app_labels(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        label_a = MockLabel()
        label_b = MockLabel()
        store._update_labels = {"com.test.a": label_a, "com.test.b": label_b}
        store._sync_update_banner(AppUpdateState.UPDATES_AVAILABLE, [
            {"fullname": "com.test.a", "name": "A"},
        ])
        self.assertFalse(label_a.has_flag(HIDDEN_FLAG))
        self.assertTrue(label_b.has_flag(HIDDEN_FLAG))

    def test_on_update_state_change_dispatches_threadsafe(self):
        from appstore_core import AppUpdateState
        store = self._make_store()
        calls = []
        store.update_ui_threadsafe_if_foreground = lambda func, state, **kw: calls.append((func, state))
        store._on_update_state_change(AppUpdateState.UPDATES_AVAILABLE)
        self.assertEqual(len(calls), 1, "state change should marshal to the main thread")
        self.assertEqual(calls[0][0], store._apply_update_state_change)
        self.assertEqual(calls[0][1], AppUpdateState.UPDATES_AVAILABLE)

    def test_on_update_state_change_updates_banner(self):
        from appstore_core import AppUpdateManager, AppUpdateState
        store = self._make_store()
        store._has_foreground = True
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum.updatable_apps = [{"fullname": "com.test.a", "name": "A"}]
        aum.current_state = AppUpdateState.UPDATES_AVAILABLE
        try:
            store._apply_update_state_change(AppUpdateState.UPDATES_AVAILABLE)
            self.assertEqual(store.update_all_label._text, "Update 1 App")
        finally:
            AppUpdateManager._instance = None

    def test_on_update_state_change_rebuilds_list_for_updates_category(self):
        from appstore_core import AppUpdateManager, AppUpdateState
        store = self._make_store()
        store._has_foreground = True
        store._selected_category = "Updates"
        store._data_loaded = True
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum.updatable_apps = [{"fullname": "com.test.a", "name": "A"}]
        aum.current_state = AppUpdateState.UPDATES_AVAILABLE
        rebuild_calls = []
        store.create_apps_list = lambda: rebuild_calls.append(True)
        try:
            store._apply_update_state_change(AppUpdateState.UPDATES_AVAILABLE)
            self.assertEqual(store.update_all_label._text, "Update 1 App")
            self.assertEqual(len(rebuild_calls), 1,
                             "list should be rebuilt when updates arrive while viewing Updates category")
        finally:
            AppUpdateManager._instance = None

    def test_on_update_state_change_does_not_rebuild_for_other_categories(self):
        from appstore_core import AppUpdateManager, AppUpdateState
        store = self._make_store()
        store._has_foreground = True
        store._selected_category = "Games"
        store._data_loaded = True
        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum.updatable_apps = [{"fullname": "com.test.a", "name": "A"}]
        aum.current_state = AppUpdateState.UPDATES_AVAILABLE
        rebuild_calls = []
        store.create_apps_list = lambda: rebuild_calls.append(True)
        try:
            store._apply_update_state_change(AppUpdateState.UPDATES_AVAILABLE)
            self.assertEqual(store.update_all_label._text, "Update 1 App")
            self.assertEqual(len(rebuild_calls), 0,
                             "list should NOT be rebuilt when viewing non-Updates category")
        finally:
            AppUpdateManager._instance = None


# ---------------------------------------------------------------------------
# Bug reproduction: AppStore reads from wrong data source before auto-check
# ---------------------------------------------------------------------------

class TestAppStorePreAutoCheck(unittest.TestCase):
    """When the AppStore is opened before the auto-update background check:
    - create_apps_list() correctly identifies updatable apps via local check
      and writes the results to AppUpdateManager.updatable_apps
    - All consumers (_update_all_click, _update_category_dropdown) then see
      consistent data
    """

    def setUp(self):
        import asyncio
        import mpos
        import appstore_core

        asyncio.new_event_loop()

        self._orig_aum = appstore_core.AppUpdateManager
        appstore_core.AppUpdateManager = _MockAUM
        _MockAUM.reset_instance()

        self._install_calls = []
        self._orig_dl_install = appstore_module.install_package

        async def _fake_install(app_data, **kwargs):
            url, fullname = app_data["download_url"], app_data["fullname"]
            self._install_calls.append((url, fullname))

        appstore_module.install_package = _fake_install

        self._tasks_created = []
        self._orig_create_task = mpos.TaskManager.create_task

        def _capture_task(coro):
            self._tasks_created.append(coro)
            import asyncio as _asyncio
            _asyncio.get_event_loop().run_until_complete(coro)

        mpos.TaskManager.create_task = _capture_task

        self._orig_refresh = mpos.AppManager.refresh_apps
        self._refresh_calls = []
        mpos.AppManager.refresh_apps = lambda: self._refresh_calls.append(True)

        self._orig_iav = mpos.AppManager.is_update_available
        mpos.AppManager.is_update_available = staticmethod(lambda fn, v: True)

    def tearDown(self):
        import mpos
        import appstore_core
        appstore_core.AppUpdateManager = self._orig_aum
        _MockAUM.reset_instance()
        appstore_module.install_package = self._orig_dl_install
        mpos.TaskManager.create_task = self._orig_create_task
        mpos.AppManager.refresh_apps = self._orig_refresh
        mpos.AppManager.is_update_available = self._orig_iav

    def _make_store(self):
        from appstore import AppStore
        store = AppStore()
        store.prefs = MockPrefs(None)
        store.please_wait_label = MockLabel()
        store._refresh_in_progress = False
        store._data_loaded = True
        store.update_all_button = MockLabel()
        store.update_all_label = MockLabel()
        store.main_screen = MockLabel()
        store.apps = []
        store._update_labels = {}
        store._wip_apps = []
        store._builtin_fullnames = set()
        store.category_dropdown = None
        store._icon_timer = None
        store._displayed_apps = []
        store._download_in_progress = False
        store._icon_pipeline = "none"
        store._has_foreground = True
        return store

    def test_update_all_button_click_triggers_installs(self):
        """Bug 1: _update_all_click reads AppUpdateManager.updatable_apps
        which is empty before auto-check. The fix makes create_apps_list()
        write its local results to the singleton."""
        store = self._make_store()
        self.assertFalse(_MockAUM.get_instance().updatable_apps,
                         "pre-condition: singleton must be empty before create_apps_list")

        store.refresh_list = lambda: None
        from mpos import App
        app = App("TestApp", "Pub", "desc", "", "", "http://x/a.mpk", "com.test.a", "1.0")
        app.installed_path = "apps/com.test.a"
        app._remote_version = "2.0"
        app.short_description = "desc"
        app.categories = ["Tools"]
        store.apps = [app]

        store.create_apps_list()

        self.assertEqual(len(_MockAUM.get_instance().updatable_apps), 1,
                         "create_apps_list() must write to AppUpdateManager.updatable_apps")
        self.assertFalse(store.update_all_button.has_flag(HIDDEN_FLAG),
                         "button should be visible after local check")

        store._update_all_click(None)

        self.assertTrue(self._install_calls,
                        "button click should trigger installs, not silently return")

    def test_updates_dropdown_shows_correct_count(self):
        """Bug 2: _update_category_dropdown reads AppUpdateManager.updatable_apps
        which is empty before auto-check. The fix makes create_apps_list()
        write its local results to the singleton before the dropdown is built."""
        store = self._make_store()
        self.assertFalse(_MockAUM.get_instance().updatable_apps,
                         "pre-condition: singleton must be empty before create_apps_list")

        from mpos import App
        app = App("TestApp", "Pub", "desc", "", "", "", "com.test.a", "1.0")
        app.installed_path = "apps/com.test.a"
        app._remote_version = "2.0"
        app.short_description = "desc"
        app.categories = ["Tools"]
        store.apps = [app]

        mock_dd = MockDropdown()
        store.category_dropdown = mock_dd

        store.create_apps_list()

        self.assertEqual(len(_MockAUM.get_instance().updatable_apps), 1,
                         "create_apps_list() must write to AppUpdateManager.updatable_apps")
        self.assertIn("Updates (1)", mock_dd._options,
                      "dropdown should show 'Updates (1)' after create_apps_list() populates the singleton")

    def test_on_resume_syncs_with_auto_check(self):
        """Scenario 6 regression guard: when the user returns to AppStore
        after the auto-check ran in the background, onResume must sync the
        banner with the check's current state."""
        store = self._make_store()

        from appstore_core import AppUpdateState
        aum = _MockAUM.get_instance()
        aum.updatable_apps = [
            {"fullname": "com.test.a", "name": "AppA", "_store_source": "badgehub"},
            {"fullname": "com.test.b", "name": "AppB"},
        ]
        aum.current_state = AppUpdateState.UPDATES_AVAILABLE

        store.onResume(MockLabel())

        self.assertEqual(store.update_all_label._text, "Update 2 Apps")
        self.assertFalse(store.update_all_button.has_flag(HIDDEN_FLAG))


# ---------------------------------------------------------------------------
# Icon pipeline toggle: returning from settings must refresh the list both ways
# ---------------------------------------------------------------------------

class TestAppStoreIconPipelineResume(unittest.TestCase):
    """Switching App List Icons Blocky->None in settings then backing out to
    the list left stale icon rows until restart: onResume only rebuilt for
    the None->icons direction. It must rebuild for icons->None too."""

    def setUp(self):
        import asyncio
        import appstore_core

        asyncio.new_event_loop()

        self._orig_aum = appstore_core.AppUpdateManager
        appstore_core.AppUpdateManager = _MockAUM
        _MockAUM.reset_instance()

    def tearDown(self):
        import appstore_core
        appstore_core.AppUpdateManager = self._orig_aum
        _MockAUM.reset_instance()

    def _make_store(self, pipeline, widgets):
        from appstore import AppStore
        from mpos import App
        store = AppStore()
        store.prefs = MockPrefs(None)
        store.please_wait_label = MockLabel()
        store._refresh_in_progress = False
        store._data_loaded = True
        store.update_all_button = MockLabel()
        store.update_all_label = MockLabel()
        store.main_screen = MockLabel()
        store._update_labels = {}
        store._wip_apps = []
        store._builtin_fullnames = set()
        store.category_dropdown = None
        store._icon_timer = None
        store._displayed_apps = []
        store._download_in_progress = False
        store._has_foreground = True
        store._icon_pipeline = pipeline
        store.apps_list = MockLabel()
        store._sync_update_banner = lambda *a: None
        store.apps = []
        for i, widget in enumerate(widgets):
            app = App("App%d" % i, "Pub", "desc", "", "", "", "com.test.app%d" % i, "1.0")
            app.image_icon_widget = widget
            store.apps.append(app)
        return store

    def _resume(self, store):
        rebuilds = []
        store.create_apps_list = lambda: rebuilds.append(True)
        store.onResume(MockLabel())
        return rebuilds

    def test_resume_rebuilds_when_icons_disabled_with_stale_widgets(self):
        store = self._make_store("none", [object(), object()])
        rebuilds = self._resume(store)
        self.assertEqual(len(rebuilds), 1,
                         "Blocky->None must rebuild the list to drop icon slots")

    def test_resume_skips_rebuild_when_already_iconless(self):
        store = self._make_store("none", [None, None])
        rebuilds = self._resume(store)
        self.assertEqual(len(rebuilds), 0,
                         "no rebuild when rows already have no icon slots")

    def test_resume_rebuilds_when_icons_enabled_without_slots(self):
        store = self._make_store("blurhash", [None, None])
        rebuilds = self._resume(store)
        self.assertEqual(len(rebuilds), 1,
                         "None->Blocky must still rebuild the list with icon slots")


# ---------------------------------------------------------------------------
# Viewport icon loader: only visible rows get icon work, for every pipeline
# ---------------------------------------------------------------------------

class _MockIconWidget:
    def __init__(self):
        self.src_count = 0

    def set_src(self, src):
        self.src_count += 1

    def set_scale(self, scale):
        pass


class _MockRow:
    def __init__(self, y, h):
        self._y = y
        self._h = h

    def get_y(self):
        return self._y

    def get_height(self):
        return self._h


class _MockAppsList:
    def __init__(self, count, row_h=64, list_h=320, scroll_y=0):
        self._rows = [_MockRow(i * row_h, row_h) for i in range(count)]
        self._list_h = list_h
        self._scroll_y = scroll_y

    def update_layout(self):
        pass

    def get_scroll_y(self):
        return self._scroll_y

    def get_height(self):
        return self._list_h

    def get_child_count(self):
        return len(self._rows)

    def get_child(self, i):
        return self._rows[i]


class _FakeScrollEvent:
    def __init__(self, code):
        self._code = code

    def get_code(self):
        return self._code


class TestAppStoreViewportIconLoader(unittest.TestCase):
    _HASH = "UBMOZfK1GG%LBBNG,;Rj2skq=eE1s9n4S5Na"

    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def _make_store(self, pipeline, n, scroll_y=0, **app_kwargs):
        from appstore import AppStore
        from mpos import App
        store = AppStore()
        store._icon_pipeline = pipeline
        store._icon_timer = None
        store._displayed_apps = []
        store._download_in_progress = False
        store._has_foreground = True
        store.apps_list = _MockAppsList(n, scroll_y=scroll_y)
        store.apps = []
        for i in range(n):
            app = App("App%d" % i, "Pub", "desc", "", app_kwargs.get("icon_url", ""), "",
                      "com.test.app%d" % i, "1.0",
                      blur_hash=app_kwargs.get("blur_hash"),
                      icon_data=app_kwargs.get("icon_data"))
            app.image_icon_widget = _MockIconWidget()
            if "stage" in app_kwargs:
                app._icon_stage = app_kwargs["stage"]
            store.apps.append(app)
        store._displayed_apps = list(store.apps)
        return store

    def _stages(self, store):
        return [getattr(a, "_icon_stage", None) for a in store.apps]

    def test_raw_pipeline_loads_visible_plus_margin_only(self):
        store = self._make_store("raw", 20)
        store._load_viewport_icons(None)
        stages = self._stages(store)
        self.assertEqual(stages[:4], ["raw"] * 4,
                         "first tick fills up to the per-tick raw cap")
        self.assertEqual(stages[4:], [None] * 16,
                         "far off-screen rows must not burn icon work")
        store._load_viewport_icons(None)
        store._load_viewport_icons(None)
        stages = self._stages(store)
        self.assertEqual(stages[:10], ["raw"] * 10,
                         "remaining visible rows fill in on the next quiet ticks")
        self.assertEqual(stages[10:], [None] * 10)

    def test_scrolling_skips_ticks_then_loads_new_rows(self):
        store = self._make_store("raw", 20)
        for _ in range(3):
            store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[:10], ["raw"] * 10)
        store.apps_list._scroll_y = 640
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[10:], [None] * 10,
                         "the tick that observes motion must do no icon work")
        for _ in range(8):
            store._load_viewport_icons(None)
        self.assertTrue(all(s == "raw" for s in self._stages(store)),
                        "after scrolling stops, new rows fill in")

    def test_scroll_hold_freezes_loader(self):
        import lvgl as lv
        store = self._make_store("raw", 20)
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[:4], ["raw"] * 4)
        store._on_list_scroll(_FakeScrollEvent(lv.EVENT.SCROLL_BEGIN))
        for i in range(1, 5):
            store.apps_list._scroll_y = i * 64
            store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[:4], ["raw"] * 4)
        self.assertEqual(self._stages(store)[4:], [None] * 16,
                         "no icon work while scrolling is held or moving")
        store._on_list_scroll(_FakeScrollEvent(lv.EVENT.SCROLL_END))
        store._load_viewport_icons(None)
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[4:], [None] * 16,
                         "settle ticks after scroll end still do no work")
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[:8], ["raw"] * 8,
                         "work resumes once scrolling settles")

    def test_missed_scroll_end_auto_recovers(self):
        import lvgl as lv
        store = self._make_store("raw", 20)
        store._last_scroll_y = 0
        store._stable_ticks = store._SETTLE_TICKS
        store._on_list_scroll(_FakeScrollEvent(lv.EVENT.SCROLL_BEGIN))
        for _ in range(4):
            store._load_viewport_icons(None)
        self.assertEqual(self._stages(store)[:4], ["raw"] * 4,
                         "a stale hold must clear once scrolling is stable")

    def test_scroll_hold_blocks_download_kick(self):
        import lvgl as lv
        import mpos
        store = self._make_store("download", 20, icon_url="http://x/a.mpk", stage="raw")
        store._last_scroll_y = 0
        store._stable_ticks = store._SETTLE_TICKS
        store._on_list_scroll(_FakeScrollEvent(lv.EVENT.SCROLL_BEGIN))
        tasks = []
        orig_create_task = mpos.TaskManager.create_task
        mpos.TaskManager.create_task = lambda coro: tasks.append(coro)
        try:
            store._load_viewport_icons(None)
            self.assertEqual(tasks, [])
            self.assertFalse(store._download_in_progress)
        finally:
            mpos.TaskManager.create_task = orig_create_task

    def test_blurhash_capped_per_tick(self):
        store = self._make_store("blurhash", 20, blur_hash=self._HASH, stage="raw")
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store).count("blurhash"), 1,
                         "only one blurhash decode per tick")
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store).count("blurhash"), 2,
                         "next quiet tick advances the next visible row")

    def test_download_kicked_once_for_visible(self):
        import mpos
        store = self._make_store("download", 20, icon_url="http://x/a.mpk", stage="raw")
        tasks = []
        orig_create_task = mpos.TaskManager.create_task
        mpos.TaskManager.create_task = lambda coro: tasks.append(coro)
        try:
            store._load_viewport_icons(None)
            self.assertEqual(len(tasks), 1,
                             "one download kicked for the first visible row needing it")
            self.assertTrue(store._download_in_progress)
            store._stable_ticks = store._SETTLE_TICKS
            store._load_viewport_icons(None)
            self.assertEqual(len(tasks), 1,
                             "no second download while one is in flight")
        finally:
            mpos.TaskManager.create_task = orig_create_task

    def test_cached_icons_restored_without_regeneration(self):
        store = self._make_store("raw", 3)
        restored = []
        raws = []
        store._restore_cached_icon = lambda app, widget: restored.append(app.fullname) or True
        store._set_raw_icon = lambda app: raws.append(app.fullname)
        store._load_viewport_icons(None)
        self.assertEqual(len(restored), 3)
        self.assertEqual(raws, [],
                         "restored rows must not regenerate raw icons")

    def test_finished_and_widgetless_rows_skipped(self):
        store = self._make_store("blurhash", 3, blur_hash=self._HASH, stage="blurhash")
        store.apps[1].image_icon_widget = None
        calls = []
        store._set_raw_icon = lambda app: calls.append(app)
        store._set_icon_widget = lambda app: calls.append(app)
        store._load_viewport_icons(None)
        self.assertEqual(calls, [],
                         "finished rows and rows without widgets need no work")

    def test_broken_geometry_falls_back_to_all(self):
        store = self._make_store("raw", 4)
        store.apps_list = MockLabel()
        store._load_viewport_icons(None)
        self.assertEqual(self._stages(store), ["raw"] * 4,
                         "geometry failure must degrade to loading everything")

    def test_timer_lifecycle(self):
        store = self._make_store("raw", 2)
        created = []
        deleted = []

        class _FakeTimer:
            def delete(self):
                deleted.append(True)

        store._create_timer = lambda cb, ms: created.append(ms) or _FakeTimer()
        store._start_icon_timer()
        self.assertEqual(created, [store._ICON_TICK_MS])
        self.assertIsNotNone(store._icon_timer)
        self.assertEqual(self._stages(store), ["raw"] * 2,
                         "starting the timer also does one immediate pass")
        store._stop_all_timers()
        self.assertEqual(len(deleted), 1)
        self.assertIsNone(store._icon_timer)

    def test_no_timer_when_icons_disabled(self):
        store = self._make_store("none", 2)
        created = []
        store._create_timer = lambda cb, ms: created.append(ms)
        self.assertIsNone(store._icon_timer)
        store._start_icon_timer()
        self.assertEqual(created, [],
                         "no loader timer when icons are disabled")
        self.assertIsNone(store._icon_timer)


# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Update notifications setting
# ---------------------------------------------------------------------------

class TestAppUpdateNotificationsSetting(unittest.TestCase):
    def setUp(self):
        import asyncio
        asyncio.new_event_loop()

    def tearDown(self):
        MockConnectivityManager.reset_instance()

    def _patch_aum(self, prefs_cls=MockPrefs, suppress=False):
        import appstore_core
        from appstore_core import AppUpdateManager, AppUpdateState
        import mpos

        MockConnectivityManager.reset_instance()
        orig_cm = appstore_core.ConnectivityManager
        appstore_core.ConnectivityManager = MockConnectivityManager

        orig_sp = appstore_core.SharedPreferences
        appstore_core.SharedPreferences = prefs_cls
        self._source_prefs = store_source_module.SharedPreferences
        store_source_module.SharedPreferences = prefs_cls

        notify_calls = []
        cancel_calls = []

        def _fake_notify(n):
            notify_calls.append(n)

        def _fake_cancel(nid):
            cancel_calls.append(nid)

        orig_notify = mpos.NotificationManager.notify
        orig_cancel = mpos.NotificationManager.cancel
        mpos.NotificationManager.notify = _fake_notify
        mpos.NotificationManager.cancel = _fake_cancel

        AppUpdateManager._instance = None
        aum = AppUpdateManager.get_instance()
        aum._suppress_notifications = suppress

        return {
            "aum": aum,
            "AppUpdateState": AppUpdateState,
            "appstore_core": appstore_core,
            "orig_cm": orig_cm,
            "orig_sp": orig_sp,
            "orig_notify": orig_notify,
            "orig_cancel": orig_cancel,
            "notify_calls": notify_calls,
            "cancel_calls": cancel_calls,
        }

    def _unpatch(self, ctx):
        import mpos
        ctx["appstore_core"].ConnectivityManager = ctx["orig_cm"]
        ctx["appstore_core"].SharedPreferences = ctx["orig_sp"]
        store_source_module.SharedPreferences = self._source_prefs
        mpos.NotificationManager.notify = ctx["orig_notify"]
        mpos.NotificationManager.cancel = ctx["orig_cancel"]
        ctx["appstore_core"].AppUpdateManager._instance = None
        MockConnectivityManager.reset_instance()

    def _mock_download_url(self, return_value=None, exception=None):
        import mpos.net.download_manager as dm

        async def _dl(url):
            if exception:
                raise exception
            return return_value

        orig = dm.DownloadManager.download_url
        dm.DownloadManager.download_url = staticmethod(_dl)
        return orig

    def _mock_is_update_available(self, results):
        import mpos
        orig = mpos.AppManager.is_update_available

        def _fake(fullname, version):
            return results.get(fullname, False)

        mpos.AppManager.is_update_available = staticmethod(_fake)
        return orig

    def test_background_check_runs_when_notifications_on(self):
        ctx = self._patch_aum(prefs_cls=MockPrefs, suppress=False)
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE)
                self.assertEqual(len(ctx["aum"].updatable_apps), 1)
                self.assertEqual(ctx["aum"].updatable_apps[0]["fullname"], "com.test.a")
                self.assertEqual(len(ctx["notify_calls"]), 1)
                self.assertEqual(ctx["notify_calls"][0].text, "1 app can be updated")
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_background_check_skipped_when_notifications_off(self):
        ctx = self._patch_aum(prefs_cls=MockPrefsNotificationsOff, suppress=False)
        try:
            orig_dl = self._mock_download_url(return_value="[]")
            orig_iav = self._mock_is_update_available({})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates())
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].IDLE)
                self.assertEqual(len(ctx["aum"].updatable_apps), 0)
                self.assertEqual(len(ctx["notify_calls"]), 0)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_force_check_runs_when_notifications_off(self):
        ctx = self._patch_aum(prefs_cls=MockPrefsNotificationsOff, suppress=False)
        try:
            import json
            app_index = json.dumps([
                {"slug": "com.test.a", "name": "TestA", "version": "2.0"},
            ])
            orig_dl = self._mock_download_url(return_value=app_index)
            orig_iav = self._mock_is_update_available({"com.test.a": True})
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                loop.run_until_complete(ctx["aum"].check_for_updates(force=True))
                self.assertEqual(ctx["aum"].current_state, ctx["AppUpdateState"].UPDATES_AVAILABLE)
                self.assertEqual(len(ctx["aum"].updatable_apps), 1)
                self.assertEqual(len(ctx["notify_calls"]), 0)
            finally:
                import mpos.net.download_manager as dm
                dm.DownloadManager.download_url = orig_dl
                import mpos
                mpos.AppManager.is_update_available = orig_iav
        finally:
            self._unpatch(ctx)

    def test_notify_skipped_when_notifications_off(self):
        ctx = self._patch_aum(prefs_cls=MockPrefsNotificationsOff, suppress=False)
        try:
            ctx["aum"].updatable_apps = [{"fullname": "com.test.a", "name": "TestA"}]
            ctx["aum"]._notify_updates_available()
            self.assertEqual(len(ctx["notify_calls"]), 0)
        finally:
            self._unpatch(ctx)

    def test_clear_updates_notification(self):
        ctx = self._patch_aum(prefs_cls=MockPrefs, suppress=False)
        try:
            ctx["aum"].clear_updates_notification()
            self.assertEqual(ctx["cancel_calls"], ["appstore.updates_available"])
        finally:
            self._unpatch(ctx)



suite = unittest.TestSuite()
for _k in dir():
    _v = globals()[_k]
    if isinstance(_v, type):
        try:
            if issubclass(_v, unittest.TestCase):
                suite.addTest(_v)
        except Exception:
            pass
if not _mpos_asserts_work:
    print('TEST WAS A FAILURE')
else:
    result = unittest.TextTestRunner().run(suite)
    print('TEST WAS A SUCCESS' if result.wasSuccessful() else 'TEST WAS A FAILURE')
